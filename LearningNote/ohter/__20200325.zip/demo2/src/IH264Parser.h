#pragma once
#include "PSStruct.h"

#ifndef SUPPORT_DIRECT_GET_AFRAME
#define SUPPORT_DIRECT_GET_AFRAME
#endif

#define SAFE_DEL(p)			{	if (p!=NULL){ delete p; p=NULL;}	}


class IH264Parser
{
public:
	IH264Parser(uint8_t* pPSBuffer, uint32_t nPSBufferSize) 
	: m_pPSBuffer(pPSBuffer)
	, m_nPSBufferSize(nPSBufferSize)
	, m_nPSWritePos(0) 
	, m_nLastWriteSize(0)
	{
		m_pESBuffer = new uint8_t[MAX_ES_LENGTH];	
	}

	virtual ~IH264Parser(void) 
	{
		if (m_pESBuffer != NULL)
		{
			delete[] m_pESBuffer;
			m_pESBuffer = NULL;
		}
	}

	void InitSizeData(uint32_t nInitSize)	//2015-12-29 Add �ڹ��캯�����Ѿ���������
	{
		if (m_nPSWritePos > 0 || nInitSize > m_nPSBufferSize)
			return;

		m_nPSWritePos = nInitSize;
		m_nLastWriteSize = nInitSize;
	}

	void PSWrite(uint8_t* pBuffer, uint32_t nBufSize) 
	{
		if(m_nPSWritePos + nBufSize <= m_nPSBufferSize)
		{
			memcpy((m_pPSBuffer + m_nPSWritePos), pBuffer, nBufSize);
			m_nPSWritePos += nBufSize;

			m_nLastWriteSize = nBufSize; //2015-04-30 Add
		}
		else
		{
			Clear();
		}
	}

#ifdef SUPPORT_DIRECT_GET_AFRAME
	virtual NAKED_PES_INFO GetAFrame() = 0;		
#else
	virtual NAKED_PES_INFO GetNakedPayload() = 0;
#endif

	virtual void Clear() = 0;

	uint32_t GetBufFreeSize(){ return m_nPSBufferSize-m_nPSWritePos; }

	bool HasMultipleFrame() //����ʵʱ������
	{
		if (m_nPSWritePos > m_nLastWriteSize)
		{
			return true;
		}

		return false;
	}

	virtual int GetVideoCodec() { return PS_unknown; }


protected:
	uint8_t*		  m_pPSBuffer;					//Stream������
	uint32_t		  m_nPSBufferSize;				

	uint32_t		  m_nPSWritePos;                //Streamд��λ��

	uint32_t		  m_nLastWriteSize;

	uint8_t*         m_pESBuffer;					//��֡����(������)
	uint32_t		  m_nESLength;                  //��֡���ݳ���(����������)

};
