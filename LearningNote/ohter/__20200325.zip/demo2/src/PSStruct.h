#pragma once
#include <stdint.h>
#include <string.h>

//const uint32_t  MAX_PS_LENGTH  = 0xFFFF;
//const uint32_t  MAX_PES_LENGTH = 0xFFFF;
const uint32_t  MAX_PS_LENGTH  = 0x80000; //512KB
const uint32_t  MAX_PES_LENGTH = 0x80000; //512KB
const uint32_t  MAX_ES_LENGTH = 0x100000; //1MB

const uint8_t	PS_VIDEO_FRAME_FLAG = 0xE0;
const uint8_t	PS_AUDIO_FRAME_FLAG = 0xC0;


typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

#pragma pack (1)
typedef struct ps_header
{
    unsigned char pack_start_code[4];  //'0x000001BA'

    unsigned char system_clock_reference_base21:2;
    unsigned char marker_bit:1;
    unsigned char system_clock_reference_base1:3;
    unsigned char fix_bit:2;    //'01'

    unsigned char system_clock_reference_base22;

    unsigned char system_clock_reference_base31:2;
    unsigned char marker_bit1:1;
    unsigned char system_clock_reference_base23:5;

    unsigned char system_clock_reference_base32;
    unsigned char system_clock_reference_extension1:2;
    unsigned char marker_bit2:1;
    unsigned char system_clock_reference_base33:5; //system_clock_reference_base 33bit

    unsigned char marker_bit3:1;
    unsigned char system_clock_reference_extension2:7; //system_clock_reference_extension 9bit

    unsigned char program_mux_rate1;

    unsigned char program_mux_rate2;
    unsigned char marker_bit5:1;
    unsigned char marker_bit4:1;
    unsigned char program_mux_rate3:6;

    unsigned char pack_stuffing_length:3;
    unsigned char reserved:5;

	ps_header()
	{
		memset((void*)this, 0, sizeof(ps_header));
	}

}ps_header_t;  //14

typedef struct sh_header
{
    unsigned char system_header_start_code[4]; //32

    unsigned char header_length[2];            //16 uimsbf

    uint32_t marker_bit1:1;   //1  bslbf
    uint32_t rate_bound:22;   //22 uimsbf
    uint32_t marker_bit2:1;   //1 bslbf
    uint32_t audio_bound:6;   //6 uimsbf
    uint32_t fixed_flag:1;    //1 bslbf
    uint32_t CSPS_flag:1;     //1 bslbf

    uint16_t system_audio_lock_flag:1;  // bslbf
    uint16_t system_video_lock_flag:1;  // bslbf
    uint16_t marker_bit3:1;             // bslbf
    uint16_t video_bound:5;             // uimsbf
    uint16_t packet_rate_restriction_flag:1; //bslbf
    uint16_t reserved_bits:7;                //bslbf
    unsigned char reserved[6];

	sh_header()
	{
		memset((void*)this, 0, sizeof(sh_header));
	}
}sh_header_t; //18

typedef struct psm_header
{
    unsigned char promgram_stream_map_start_code[4];

    unsigned char program_stream_map_length[2];

    unsigned char program_stream_map_version:5;
    unsigned char reserved1:2;
    unsigned char current_next_indicator:1;

    unsigned char marker_bit:1;
    unsigned char reserved2:7;

    unsigned char program_stream_info_length[2];
    unsigned char elementary_stream_map_length[2];
    unsigned char stream_type;
    unsigned char elementary_stream_id;
    unsigned char elementary_stream_info_length[2];
    unsigned char CRC_32[4];
    unsigned char reserved[16];

	psm_header()
	{
		memset((void*)this, 0, sizeof(psm_header));
	}
}psm_header_t; //36

typedef struct pes_header
{
    unsigned char pes_start_code_prefix[3];
    unsigned char stream_id;
    unsigned short PES_packet_length;

	pes_header()
	{
		memset((void*)this, 0, sizeof(pes_header));
	}
}pes_header_t; //6

typedef struct optional_pes_header
{
    unsigned char original_or_copy:1;
    unsigned char copyright:1;
    unsigned char data_alignment_indicator:1;
    unsigned char PES_priority:1;
    unsigned char PES_scrambling_control:2;
    unsigned char fix_bit:2;

    unsigned char PES_extension_flag:1;
    unsigned char PES_CRC_flag:1;
    unsigned char additional_copy_info_flag:1;
    unsigned char DSM_trick_mode_flag:1;
    unsigned char ES_rate_flag:1;
    unsigned char ESCR_flag:1;
    unsigned char PTS_DTS_flags:2;

    unsigned char PES_header_data_length;

	optional_pes_header()
	{
		memset((void*)this, 0, sizeof(optional_pes_header));
	}
}optional_pes_header_t;

#pragma pack ()


enum PSStatus
{
    ps_padding, //δ֪״̬
    ps_ps,      //ps״̬
    ps_sh,
    ps_psm,
    ps_pes,
    ps_pes_video,
    ps_pes_audio
};

/*
_1 �Ƿ��������
_2 ��һ��PS״̬
_3 ����ָ��
_4 ���ݳ���
*/

struct PES_INFO
{
	bool		bValid;
	bool		bIFrame;	//2014-04-10 Add
	PSStatus	status;
	pes_header_t* pesHeader;

	PES_INFO()
	{
		memset((void*)this, 0, sizeof(PES_INFO));
	}
};


/*
_1 �Ƿ��������
_2 ��������
_3 PTSʱ���
_4 DTSʱ���
_5 ����ָ��
_6 ���ݳ���
*/

struct NAKED_PES_INFO
{
	bool		bValid;
	bool		bIFrame;	//2014-04-10 Add
	uint8_t		byType;
	bool		bFrameNotFull;	//֡�е����ݲ����� 2015-09-08 Add

	uint64_t		pts;
	uint64_t		dts;

	uint8_t*		pESBuffer;
	uint32_t		nESLength;

	NAKED_PES_INFO()
	{
		memset((void*)this, 0, sizeof(NAKED_PES_INFO));
	}
};

//2014-03-17 Add ������PS��
struct PS_PACKET_INFO
{
	bool		bValid;
	bool		bIFrame;	//2014-10-21 Add
	uint8_t		byType;

	uint64_t		pts;
	uint64_t		dts;

	uint8_t*		pPSBuffer;
	uint32_t		nPSLength;

	uint32_t		nBufSize;

	PS_PACKET_INFO()
	{
		memset((void*)this, 0, sizeof(PS_PACKET_INFO));
	}
};

//2016-07-14 Add
enum PS_PAYLOAD_TYPE
{
	ps_payload_padding,			//δ֪״̬
	ps_payload_sps,				//Sequence parameter set
	ps_payload_pps,				//Picture parameter set
	ps_payload_slice_idr,		//Coded slice of an IDR picture
	ps_payload_slice_non_idr,	//Coded slice of a non-IDR picture
	ps_payload_sei,				//Supplemental enhancement information

	ps_payload_audio,		
};

enum PS_VIDEO_CODEC
{
    PS_unknown,
    PS_h264,
    PS_h265,
    PS_mpeg4,
    PS_svac,
};

