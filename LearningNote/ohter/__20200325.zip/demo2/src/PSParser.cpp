#include "PSParser.h"

#ifdef _MSC_VER
#include <WinSock.h>
#else
#include <netinet/in.h>
#endif

#include <string.h>
#include <stdio.h>


bool bStartPrint = false;


CPSParser::CPSParser(uint8_t* pPSBuffer, uint32_t nPSBufferSize)
: IH264Parser(pPSBuffer, nPSBufferSize)
, m_ps(NULL)
, m_sh(NULL)
, m_psm(NULL)
, m_pes(NULL)
#ifdef SUPPORT_DIRECT_GET_AFRAME
, m_nextdts(0)
, m_bFrameHeader(false)
#endif
, m_bVideoFrame(true)
//, m_bLastValid(true)
//, m_nMinParseLength(0)
, m_payloadType(ps_payload_padding)
{
	Clear();

	//m_pPSBuffer = new char[MAX_PS_LENGTH];	

	m_pPESBuffer = new uint8_t[MAX_PES_LENGTH];	

}

CPSParser::~CPSParser(void)
{
	/*if (m_pPSBuffer != NULL)
	{
		delete[] m_pPSBuffer;
		m_pPSBuffer = NULL;
	}*/

	if (m_pPESBuffer != NULL)
	{
		delete[] m_pPESBuffer;
		m_pPESBuffer = NULL;
	}
}

void CPSParser::Clear()
{
	m_status = ps_padding;

	m_nESLength = 0;
	m_nPESIndicator = 0;
	m_nPSWritePos = 0;
	m_nPESLength = 0;

#ifdef SUPPORT_DIRECT_GET_AFRAME
	m_nPSStartPos = 0;

	m_nextStatus = ps_padding;
	m_nNextPESIndicator = 0;
	m_nextStreamID = 0xE0;
#endif

	m_nH264PES_packet_length = 0;
	m_nH264PS_packet_length = 0;

	m_frameParser.Reset();
}

bool CPSParser::FlushData(uint8_t* & pBuf, uint32_t& nDataLength)
{
	if (m_nPSWritePos > 0)
	{
		pBuf = m_pPSBuffer;
		nDataLength = m_nPSWritePos;

		Clear();
		return true;
	}

	return false;
}

#ifdef SUPPORT_DIRECT_GET_AFRAME

NAKED_PES_INFO CPSParser::GetAFrame()
{
	bool bContinue = false;

	m_bVideoFrame = false;

	NAKED_PES_INFO nakedPes;

	bool bHasFrameFlag = false;	

	m_payloadType = ps_payload_padding;

	/*if (!m_bLastValid)
	{
		if (m_nPSWritePos < m_nMinParseLength)
		{
			return nakedPes;
		}
		
	}*/
	

	//2015-04-03 Add 
	bool bFirstPes = true;
	bool bH264ParamSet = false; //H264 Sequence Parameter Set

	bool bFirstNextPtsZero = true;	//2017-08-22 Add

	do 
	{
		bContinue = false;
		PES_INFO pesInfo = GetFrame_pes_payload();
		if (!pesInfo.bValid)
		{
			if (m_status == ps_padding && ! IsReadEnd())
			{
				bContinue = true;
				continue;	//2016-03-02 Add
			}

			nakedPes.bValid = false;	//2014-07-22 Add

			break;
		}

		bHasFrameFlag = true;

		PSStatus status = pesInfo.status;
		pes_header_t* pes = pesInfo.pesHeader;
		optional_pes_header* option = (optional_pes_header*)((char*)pes + sizeof(pes_header_t));
		if(option->PTS_DTS_flags != 2 && option->PTS_DTS_flags != 3 && option->PTS_DTS_flags != 0)
		{
			break;
		}
		uint64_t pts = m_psAnalyzer.get_pts(option);
		uint64_t dts = m_psAnalyzer.get_dts(option);
		unsigned char stream_id = pes->stream_id;

		//if (pts == 3187350 || pts == 3183750)
		//{
		//	Sleep(1);
		//}

		//2014-09-25 Add
		unsigned short PES_packet_length = ntohs(pes->PES_packet_length);
		if (PES_packet_length != 0)
		{
			if (m_nH264PES_packet_length != PES_packet_length)	//2015-09-08 Add
			{
				nakedPes.bFrameNotFull = true;
				//OutputDebug("\n *************** PES_packet_length = %d, while m_nH264PES_packet_length = %d", PES_packet_length, m_nH264PES_packet_length);
			}			

			m_nH264PES_packet_length = PES_packet_length;
		}

		char* pESBuffer = ((char*)option + sizeof(optional_pes_header) + option->PES_header_data_length);
		int nESLength = m_nH264PES_packet_length - (sizeof(optional_pes_header) + option->PES_header_data_length);
		if (nESLength < 0)	//2014-04-15 Add
		{
			break;
		}
		
		if (m_psAnalyzer.is_audio_stream_id(stream_id)) //H264 AUDIO stream_id == 0xC0
		{
			if (m_nESLength > 0)
			{
				break;
			}
		}

		if (m_nESLength+nESLength > MAX_ES_LENGTH)	//2014-07-15 Add
			break;
		
		memcpy(m_pESBuffer + m_nESLength, pESBuffer, nESLength);
		m_nESLength += nESLength;

		if(m_psAnalyzer.is_video_stream_id(stream_id) && (status == ps_ps || status == ps_pes_audio)) //stream_id == 0xE0
		{
			m_bVideoFrame = true;

			nakedPes.bValid = true;
			nakedPes.byType = 0xE0;

			nakedPes.pts = pts;
			nakedPes.dts = dts;
			if (nakedPes.dts == 0)
			{
				nakedPes.dts = nakedPes.pts;
			}

			nakedPes.pESBuffer = m_pESBuffer;
			nakedPes.nESLength = m_nESLength;

			PS_PAYLOAD_TYPE payloadType = m_psAnalyzer.GetPSPayloadType((uint8_t*)pESBuffer, nESLength); //2017-01-22 Add
			if (m_payloadType == ps_payload_padding || m_payloadType == ps_payload_sps || m_payloadType == ps_payload_pps)
			{
				if (payloadType != ps_payload_padding)
				{
					m_payloadType = payloadType;
				}
			}
		
			//if (m_status == ps_pes) //2014-07-02 Add
			//{
			//	bContinue = true;
			//	continue;
			//}

			if (bFirstPes)
			{
				bH264ParamSet = IsH264ParamSet(nakedPes.pESBuffer, nakedPes.nESLength);
				bFirstPes = false;
			}

			if (m_nextStatus == ps_ps)	//2014-07-12 Add
			{
				GetNextDts(); //2014-07-11 Add
				if (m_bFrameHeader || m_nextdts != nakedPes.dts)
				{
					if (bH264ParamSet && m_nESLength < H264_SCAN_LENGTH)	//2015-04-02 Add ĳЩPS���� H264 Sequence Parameter Set��װ��һ�������İ�
					{
						bH264ParamSet = false;
						bContinue = true;
						continue;
					}

					break;
				}				
				else
				{
					//OutputDebugString("\n m_nextdts == nakedPes.dts");

					bContinue = true;
					continue;
				}
			}
			else if (m_nextStatus == ps_pes)
			{
				//OutputDebugString("\n m_nextStatus == ps_pes");

				if (m_nextStreamID != 0xC0)
				{
					bContinue = true;
					continue;
				}
			}

		}
		else if(m_psAnalyzer.is_audio_stream_id(stream_id))
		{
			nakedPes.bValid = true;
			nakedPes.byType = 0xC0;
			nakedPes.pts = pts;
			nakedPes.dts = dts;
			if (nakedPes.dts == 0)
			{
				nakedPes.dts = nakedPes.pts;
			}

			nakedPes.pESBuffer = m_pESBuffer;
			nakedPes.nESLength = m_nESLength;

			break;
		}
		else if (status == ps_pes) //2014-07-02 Add
		{
			nakedPes.pESBuffer = m_pESBuffer;
			nakedPes.nESLength = m_nESLength;

			PS_PAYLOAD_TYPE payloadType = m_psAnalyzer.GetPSPayloadType((uint8_t*)pESBuffer, nESLength); //2017-01-22 Add
			if (m_payloadType == ps_payload_padding || m_payloadType == ps_payload_sps || m_payloadType == ps_payload_pps)
			{
				if (payloadType != ps_payload_padding)
				{
					m_payloadType = payloadType;
				}
			}

		/*	if (bFirstPes)
			{
				bH264ParamSet = IsH264ParamSet(nakedPes.pESBuffer, nakedPes.nESLength);
				bFirstPes = false;
			}*/

			if (m_nextStatus == ps_pes)
			{
				//OutputDebugString("\n m_nextStatus == ps_pes");

				if (m_nextStreamID != 0xC0)
				{
					bContinue = true;
					continue;
				}
			}
			else if (m_nextStatus == ps_ps)	//2014-09-24 Add
			{
				GetNextDts(); //2014-07-11 Add

				if (m_nextdts == 0 && m_nPSWritePos-m_nPESIndicator < 80)	//2017-06-10 Add ����ȫ����һ������ͷ
				{
					nakedPes.bValid = false;
					break;
				}

				if (m_nextdts == 0 && bFirstNextPtsZero)	//2017-08-22 Add
				{
					bFirstNextPtsZero = false;
					continue;
				}

				if (m_bFrameHeader || m_nextdts != nakedPes.dts)
				{
					//if (m_nESLength%65500 == 0)
					//{
					//	char tempBuf[200];
					//	ZeroMemory(tempBuf, sizeof(tempBuf));
					//	sprintf(tempBuf, "\n *********** m_nESLength =  %d ************",m_nESLength);
					//	OutputDebugString(tempBuf);
					//}

					//if (m_nextdts == 0 && m_nPSWritePos - m_nPESIndicator < 100) //��ֹ���ֲ�������next pes header
					//{
					//	nakedPes.bValid = false;
					//}

					if (bH264ParamSet && m_nESLength < H264_SCAN_LENGTH)	//2015-04-02 Add ĳЩPS���� H264 Sequence Parameter Set��װ��һ�������İ�
					{
						bH264ParamSet = false;
						bContinue = true;
						continue;
					}

					break;
				}				
				else
				{
					/*char tempBuf[200];
					ZeroMemory(tempBuf, sizeof(tempBuf));
					sprintf(tempBuf, "\n m_nextdts =  %I64d nakedPes.dts = %I64d", m_nextdts, nakedPes.dts);
					OutputDebugString(tempBuf);*/

					//OutputDebugString("\n m_nextdts =  %I64d nakedPes.dts = %I64d", m_nextdts, nakedPes.dts);

					bContinue = true;
					continue;
				}
			}
		}
	} while (bContinue);

	m_nESLength = 0;


	if (nakedPes.bValid)
	{
		memmove(m_pPSBuffer, m_pPSBuffer+m_nNextPESIndicator, m_nPSWritePos-m_nNextPESIndicator);

		m_nPSWritePos -= m_nNextPESIndicator;
		m_nPESIndicator = m_nNextPESIndicator = 0;
		m_ps = (ps_header_t*)(m_pPSBuffer+m_nNextPESIndicator);
		m_pes = (pes_header_t*)(m_pPSBuffer+m_nNextPESIndicator);

		if (m_payloadType == ps_payload_slice_idr)	//2017-01-22 Add
		{
			nakedPes.bIFrame = true;
		}
		else
		{
			nakedPes.bIFrame = m_frameParser.IsIFrame(nakedPes.pESBuffer, nakedPes.nESLength);
		}

		//static int iFrameIndex = 0;
		//iFrameIndex++;
		//char tempBuf[600];
		//ZeroMemory(tempBuf, sizeof(tempBuf));
		//sprintf(tempBuf, "\n iIndex = %d, nFrameSize = %d, \t nakedPes.dts = %I64d \t", iFrameIndex, nakedPes.nESLength, nakedPes.dts);
		//////sprintf(tempBuf, "\n iIndex = %d, nFrameSize = %d", iFrameIndex, nakedPes.nESLength);
		//OutputDebugString(tempBuf);

		//if (iFrameIndex == 48 && nakedPes.nESLength == 14634)
		//{
		//	bStartPrint = true;
		//	Sleep(1);
		//}/**/

		//iIndex = 119, nFrameSize = 15909

		////if (nakedPes.bIFrame)
		//{
		//	char tempBuf[600];
		//	ZeroMemory(tempBuf, sizeof(tempBuf));
		//	sprintf(tempBuf, "\n I Frame = %d, index = %d \t length = %d \t", nakedPes.bIFrame, iFrameIndex, nakedPes.nESLength);
		//	OutputDebugString(tempBuf);

		//	for (int j = 0; j < 100; j++)
		//	{
		//		sprintf(tempBuf+3*j, "%02X ", (uint8_t)nakedPes.pESBuffer[j]);
		//	}
		//	OutputDebugString(tempBuf);
		//}	
	}
	else	//2014-07-22 Add
	{
		m_nPESIndicator = m_nNextPESIndicator = 0;	
		m_status = ps_padding;

		//if (m_bLastValid)
		//{
		//	m_nMinParseLength = 10<<10; //10k;
		//}
		//else
		//{
		//	if (m_nMinParseLength < MAX_PES_LENGTH/2)
		//	{
		//		m_nMinParseLength *= 2;
		//	}			
		//}
	}

	//m_bLastValid = nakedPes.bValid;
	return nakedPes;
}

PES_INFO CPSParser::GetFrame_pes_payload()
{
	bool bPSPacket = false;
	bool bIFrame = false;

	//char tempBuf[600];
	//ZeroMemory(tempBuf, sizeof(tempBuf));
	//sprintf(tempBuf, "\n");
	//OutputDebugString(tempBuf);

	//for (int j = 0; j < 100; j++)
	//{
	//	sprintf(tempBuf+3*j, "%02X ", (uint8_t)m_pPSBuffer[j]);
	//}
	//OutputDebugString(tempBuf);

	PES_INFO pesInfo;
	if(m_status == ps_padding)
	{
		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_ps = (ps_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_ps_header(m_ps))
			{
				m_status = ps_ps;
				bPSPacket = true;
				m_nPSStartPos = m_nPESIndicator;

				break;
			}
		}
	}

	if(m_status == ps_ps)
	{
		m_nPSStartPos = m_nPESIndicator;
		m_nPESIndicator += sizeof(ps_header_t)+m_ps->pack_stuffing_length;	//2015-04-30 Add

		bPSPacket = true;
		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_sh = (sh_header_t*)(m_pPSBuffer + m_nPESIndicator);
			m_pes = (pes_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_sh_header(m_sh))
			{
				m_status = ps_sh;
				bIFrame = true;
				break;
			}
			else if (m_psAnalyzer.is_pes_header(m_pes))
			{
				m_status = ps_pes;
				break;
			}
		}
	}

	if(m_status == ps_sh)
	{
		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_psm = (psm_header_t*)(m_pPSBuffer + m_nPESIndicator);
			m_pes = (pes_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_psm_header(m_psm))
			{
				m_status = ps_psm;//���s_sh״̬
				break;
			}
			if(m_psAnalyzer.is_pes_header(m_pes))
			{
				m_status = ps_pes;
				break;
			}
		}
	}

	if(m_status == ps_psm)
	{
		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_pes = (pes_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_pes_header(m_pes))
			{
				m_status = ps_pes;
				break;
			}
		}
	}

	if(m_status == ps_pes)
	{
		m_nextStatus = ps_padding;

		//Ѱ����һ��pes ���� ps
		m_nH264PES_packet_length = 0;		

		bool bPesHeader = false;
		//optional_pes_header* option = (optional_pes_header*)((char*)m_pes + sizeof(pes_header_t));
		//for(m_nNextPESIndicator = m_nPESIndicator+sizeof(pes_header_t)+option->PES_header_data_length; m_nNextPESIndicator<m_nPSWritePos; m_nNextPESIndicator++)
		m_nNextPESIndicator = m_nPESIndicator+sizeof(pes_header_t);
		unsigned short PES_packet_length = ntohs(((pes_header_t*)(m_pPSBuffer + m_nPESIndicator))->PES_packet_length);
		if (PES_packet_length != 0)
		{
		    m_nNextPESIndicator += PES_packet_length;
		}
		for(; m_nNextPESIndicator<m_nPSWritePos; m_nNextPESIndicator++)
		{
			pes_header_t* pes = (pes_header_t*)(m_pPSBuffer + m_nNextPESIndicator);
			ps_header_t* ps = (ps_header_t*)(m_pPSBuffer + m_nNextPESIndicator);

			bPesHeader = m_psAnalyzer.is_pes_header(pes);
			if(bPesHeader|| m_psAnalyzer.is_ps_header(ps))
			{
				/*if (bPesHeader)
				{
					if (m_bVideoFrame && m_psAnalyzer.is_pes_audio_header(pes))
					{
						continue;
					}
				}	*/	

				m_nextStreamID = pes->stream_id;

				m_nH264PES_packet_length = m_nNextPESIndicator-m_nPESIndicator-sizeof(pes_header_t);
				if(m_psAnalyzer.is_ps_header(ps))
				{
					m_nextStatus = ps_ps;
				}
				else
				{
					m_nextStatus = ps_pes;
					//m_nextStatus = m_psAnalyzer.pes_type(pes);
					//m_nextStatus = ps_ps;	//2014-04-14 Modify
				}
				break;
			}
		}

		if (m_nH264PES_packet_length != 0)
		{
			m_nPESLength = m_nH264PES_packet_length + sizeof(pes_header_t);
			if (m_nPESLength > MAX_PES_LENGTH) //2015-06-10 Add
			{
				m_nPESLength = MAX_PES_LENGTH;
			}
			memcpy(m_pPESBuffer, m_pes, m_nPESLength);
			

			//uint8_t* next = (m_pPSBuffer + m_nPESIndicator + sizeof(pes_header_t) + m_nH264PES_packet_length);
			//int remain = m_nPSBufferSize - (next - m_pPSBuffer);
			//memcpy(m_pPSBuffer, next, remain);
			//m_nPSBufferSize = remain; 
			//m_nPESIndicator = 0;

			m_nPESIndicator = m_nNextPESIndicator;
			m_ps = (ps_header_t*)(m_pPSBuffer+m_nNextPESIndicator);
			m_pes = (pes_header_t*)(m_pPSBuffer+m_nNextPESIndicator);

			pesInfo.bValid = true;
			pesInfo.bIFrame = bIFrame;

			if (bPSPacket)
			{
				pesInfo.status = ps_ps;
			}
			else
			{
				pesInfo.status = m_status;
			}

			m_status = m_nextStatus;
			pesInfo.pesHeader = (pes_header_t*)m_pPESBuffer;
			return pesInfo;
		}
		else
		{
			//	TRACE("\n PES_packet_length = %d", m_nH264PES_packet_length);
			m_status = ps_padding;
		}		
	}

	pesInfo.status = ps_padding;
	return pesInfo;
}

void CPSParser::GetNextDts()
{
	m_bFrameHeader = false;
	m_nextdts = 0;

	ps_header_t* ps;
	pes_header_t*  pes;
	PSStatus status = ps_ps;

	uint32_t nPESIndicator = m_nPESIndicator;
	while (nPESIndicator<m_nPSWritePos)
	{
		ps = (ps_header_t*)(m_pPSBuffer + nPESIndicator);
		pes = (pes_header_t*)(m_pPSBuffer + nPESIndicator);
		if(m_psAnalyzer.is_ps_header(ps))		//2015-04-30 Add 
		{
			nPESIndicator += sizeof(ps_header_t) + ps->pack_stuffing_length;
			continue;
		}
		else if (m_psAnalyzer.is_pes_header(pes))
		{
			optional_pes_header* option = (optional_pes_header*)((char*)pes + sizeof(pes_header_t));
			if(option->PTS_DTS_flags != 2 && option->PTS_DTS_flags != 3 && option->PTS_DTS_flags != 0)
			{
				nPESIndicator++;
				continue;
			}

			//OutputDebug("stream_id = %02x", stream_id);

			unsigned char stream_id = pes->stream_id;	//2015-06-09 Add
			if (stream_id == 0xC0)  //audio frame
			{
				nPESIndicator++;
				continue;
			}

			m_nextdts = m_psAnalyzer.get_dts(option);
			if (m_nextdts == 0) //2014-07-15 Add
			{
				m_nextdts = m_psAnalyzer.get_pts(option); //dts = pts
			}

		//	OutputDebug("\n m_nextdts = %I64u\n", m_nextdts);

			char* pESBuffer = ((char*)option + sizeof(optional_pes_header) + option->PES_header_data_length);
			if (pESBuffer[0] == 0x00 && pESBuffer[1] == 0x00 && pESBuffer[2] == 0x00 && pESBuffer[3] == 0x01) //new frame
			{
				m_bFrameHeader = true;
			}	

			break;
		}
		else
		{
			nPESIndicator++;
		}
	}

	//if (status == ps_pes)
	//{
	//	optional_pes_header* option = (optional_pes_header*)((char*)pes + sizeof(pes_header_t));
	//	if(option->PTS_DTS_flags != 2 && option->PTS_DTS_flags != 3 && option->PTS_DTS_flags != 0)
	//	{
	//		return;
	//	}

	//	m_nextdts = m_psAnalyzer.get_dts(option);
	//	if (m_nextdts == 0) //2014-07-15 Add
	//	{
	//		m_nextdts = m_psAnalyzer.get_pts(option); //dts = pts
	//	}

	//	char* pESBuffer = ((char*)option + sizeof(optional_pes_header) + option->PES_header_data_length);
	//	if (pESBuffer[0] == 0x00 && pESBuffer[1] == 0x00 && pESBuffer[2] == 0x00 && pESBuffer[3] == 0x01) //new frame
	//	{
	//		m_bFrameHeader = true;
	//	}	
	//}
}

#else

NAKED_PES_INFO CPSParser::GetNakedPayload()
{
	NAKED_PES_INFO nakedPes;
	do 
	{
		PES_INFO pesInfo = pes_payload();
		if (!pesInfo.bValid)
		{
			break;
		}

		PSStatus status = pesInfo.status;
		pes_header_t* pes = pesInfo.pesHeader;
		optional_pes_header* option = (optional_pes_header*)((char*)pes + sizeof(pes_header_t));
		if(option->PTS_DTS_flags != 2 && option->PTS_DTS_flags != 3 && option->PTS_DTS_flags != 0)
		{
			break;
		}
		unsigned __int64 pts = m_psAnalyzer.get_pts(option);
		unsigned __int64 dts = m_psAnalyzer.get_dts(option);
		unsigned char stream_id = pes->stream_id;

		//unsigned short PES_packet_length = ntohs(pes->PES_packet_length);

		//2014-09-25 Add
		unsigned short PES_packet_length = ntohs(pes->PES_packet_length);
		if (PES_packet_length != 0)
		{
			if (m_nH264PES_packet_length != PES_packet_length)	//2015-09-08 Add
			{
				nakedPes.bFrameNotFull = true;
			}

			m_nH264PES_packet_length = PES_packet_length;
		}

		char* pESBuffer = ((char*)option + sizeof(optional_pes_header) + option->PES_header_data_length);
		int nESLength = m_nH264PES_packet_length - (sizeof(optional_pes_header) + option->PES_header_data_length);
		if (nESLength < 0)	//2014-04-15 Add
		{
			break;
		}

		if (m_nESLength+nESLength > MAX_ES_LENGTH)	//2014-07-15 Add
			break;

		memcpy(m_pESBuffer + m_nESLength, pESBuffer, nESLength);
		m_nESLength += nESLength;
		if(m_psAnalyzer.is_video_stream_id(stream_id) && (status == ps_ps || status == ps_pes_audio))
		{
			nakedPes.bValid = true;
			nakedPes.byType = 0xE0;
			nakedPes.pts = pts;
			nakedPes.dts = dts;
			nakedPes.pESBuffer = m_pESBuffer;
			nakedPes.nESLength = m_nESLength;

			m_nESLength = 0;
		}
		else if(m_psAnalyzer.is_audio_stream_id(stream_id))
		{
			nakedPes.bValid = true;
			nakedPes.byType = 0xC0;
			nakedPes.pts = pts;
			nakedPes.dts = dts;
			nakedPes.pESBuffer = m_pESBuffer;
			nakedPes.nESLength = m_nESLength;

			m_nESLength = 0;
		}
	} while (false);

	return nakedPes;
}

PES_INFO CPSParser::pes_payload()
{
	bool bPSPacket = false;
	bool bIFrame = false;

	PES_INFO pesInfo;
	if(m_status == ps_padding)
	{
		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_ps = (ps_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_ps_header(m_ps))
			{
				bPSPacket = true;
				m_status = ps_ps;
				break;
			}
		}
	}

	if(m_status == ps_ps)
	{
		bPSPacket = true;

		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_sh = (sh_header_t*)(m_pPSBuffer + m_nPESIndicator);
			m_pes = (pes_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_sh_header(m_sh))
			{
				bIFrame = true;
				m_status = ps_sh;
				break;
			}
			else if (m_psAnalyzer.is_pes_header(m_pes))
			{
				m_status = ps_pes;
				break;
			}
		}
	}

	if(m_status == ps_sh)
	{
		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_psm = (psm_header_t*)(m_pPSBuffer + m_nPESIndicator);
			m_pes = (pes_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_psm_header(m_psm))
			{
				m_status = ps_psm;//���s_sh״̬
				break;
			}
			if(m_psAnalyzer.is_pes_header(m_pes))
			{
				m_status = ps_pes;
				break;
			}
		}
	}

	if(m_status == ps_psm)
	{
		for(; m_nPESIndicator<m_nPSWritePos; m_nPESIndicator++)
		{
			m_pes = (pes_header_t*)(m_pPSBuffer + m_nPESIndicator);
			if(m_psAnalyzer.is_pes_header(m_pes))
			{
				m_status = ps_pes;
				break;
			}
		}
	}

	if(m_status == ps_pes)
	{
		PSStatus nextStatus = ps_padding;

		//Ѱ����һ��pes ���� ps
		m_nH264PES_packet_length = 0;		
		optional_pes_header* option = (optional_pes_header*)((char*)m_pes + sizeof(pes_header_t));
		for(uint32_t nNextPESIndicator = m_nPESIndicator+sizeof(pes_header_t)+option->PES_header_data_length; nNextPESIndicator<m_nPSWritePos; nNextPESIndicator++)
		{
			pes_header_t* pes = (pes_header_t*)(m_pPSBuffer + nNextPESIndicator);
			ps_header_t* ps = (ps_header_t*)(m_pPSBuffer + nNextPESIndicator);
			if(m_psAnalyzer.is_pes_header(pes) || m_psAnalyzer.is_ps_header(ps))
			{
				m_nH264PES_packet_length = nNextPESIndicator-m_nPESIndicator-sizeof(pes_header_t);
				if(m_psAnalyzer.is_ps_header(ps))
				{
					nextStatus = ps_ps;
				}
				else
				{
					nextStatus = ps_pes; //2014-07-02 Modify

					//status = m_psAnalyzer.pes_type(pes);
				}
				break;
			}
		}

		if (m_nH264PES_packet_length != 0)
		{
			m_nPESLength = m_nH264PES_packet_length + sizeof(pes_header_t);
			if (m_nPESLength > MAX_PES_LENGTH) //2015-06-10 Add
			{
				m_nPESLength = MAX_PES_LENGTH;
			}
			memcpy(m_pPESBuffer, m_pes, m_nPESLength);
		

			uint8_t* next = (m_pPSBuffer + m_nPESIndicator + m_nPESLength);
			int remain = m_nPSWritePos - (next - m_pPSBuffer);
			memcpy(m_pPSBuffer, next, remain);
			m_nPSWritePos = remain; 
			m_nPESIndicator = 0;
			m_ps = (ps_header_t*)m_pPSBuffer;
			m_pes = (pes_header_t*)m_pPSBuffer;

			pesInfo.bIFrame = bIFrame;	//2014-07-02 Add

			pesInfo.bValid = true;
			if (bPSPacket)
			{
				pesInfo.status = ps_ps;
			}
			else
			{
				pesInfo.status = m_status;
			}
			m_status = nextStatus;

			pesInfo.pesHeader = (pes_header_t*)m_pPESBuffer;
			return pesInfo;
		}
		else
		{
			//	TRACE("\n PES_packet_length = %d", m_nH264PES_packet_length);
			m_status = ps_padding;

			if (m_nPSWritePos < m_nPSBufferSize/2)
			{
				m_nPESIndicator = 0;
				//m_nPSWritePos = 0;

			}
		}		
	}

	pesInfo.status = ps_padding;
	return pesInfo;
}

#endif


bool CPSParser::GetPSPacket(PS_PACKET_INFO& psPacket)
{
	psPacket.bValid = false;

	/*if (!m_bLastValid)
	{
		if (m_nPSWritePos < m_nMinParseLength)
		{
			return false;
		}
		
	}*/
	
	bool bContinue = false;
	NAKED_PES_INFO nakedPes;

	bool bHasFrameFlag = false;	

	m_payloadType = ps_payload_padding;
	//2015-04-03 Add 
	bool bFirstPes = true;
	bool bH264ParamSet = false; //H264 Sequence Parameter Set

	bool bFirstNextPtsZero = true;	//2017-08-22 Add

	do 
	{
		bContinue = false;
		PES_INFO pesInfo = GetFrame_pes_payload();
		if (!pesInfo.bValid)
		{
			if (m_status == ps_padding && ! IsReadEnd())
			{
				bContinue = true;
				continue;	//2016-03-02 Add
			}

			nakedPes.bValid = false;	//2014-07-22 Add

			break;
		}

		bHasFrameFlag = true;

		PSStatus status = pesInfo.status;
		pes_header_t* pes = pesInfo.pesHeader;
		optional_pes_header* option = (optional_pes_header*)((char*)pes + sizeof(pes_header_t));
		if(option->PTS_DTS_flags != 2 && option->PTS_DTS_flags != 3 && option->PTS_DTS_flags != 0)
		{
			break;
		}
		uint64_t pts = m_psAnalyzer.get_pts(option);
		uint64_t dts = m_psAnalyzer.get_dts(option);
		unsigned char stream_id = pes->stream_id;

		unsigned short PES_packet_length = ntohs(pes->PES_packet_length);
		if (PES_packet_length != 0)
		{
			if (m_nH264PES_packet_length != PES_packet_length)	//2015-09-08 Add
			{
				nakedPes.bFrameNotFull = true;
			}			

			m_nH264PES_packet_length = PES_packet_length;
		}

		char* pESBuffer = ((char*)option + sizeof(optional_pes_header) + option->PES_header_data_length);
		int nESLength = m_nH264PES_packet_length - (sizeof(optional_pes_header) + option->PES_header_data_length);
		if (nESLength < 0)	//2014-04-15 Add
		{
			break;
		}
		
		if (m_psAnalyzer.is_audio_stream_id(stream_id)) //H264 AUDIO stream_id == 0xC0
		{
			if (m_nESLength > 0)
			{
				break;
			}
			else
			{
				bContinue = true;
				continue;
			}
		}

		if (m_nESLength+nESLength > MAX_ES_LENGTH)	//2014-07-15 Add
			break;
		
		//memcpy(m_pESBuffer + m_nESLength, pESBuffer, nESLength);
		m_nESLength += nESLength;

		if(m_psAnalyzer.is_video_stream_id(stream_id) && (status == ps_ps || status == ps_pes_audio)) //stream_id == 0xE0
		{
			nakedPes.bValid = true;
			nakedPes.byType = 0xE0;

			nakedPes.pts = pts;
			nakedPes.dts = dts;
			if (nakedPes.dts == 0)
			{
				nakedPes.dts = nakedPes.pts;
			}

			//nakedPes.pESBuffer = m_pESBuffer;
			//nakedPes.nESLength = m_nESLength;

			PS_PAYLOAD_TYPE payloadType = m_psAnalyzer.GetPSPayloadType((uint8_t*)pESBuffer, nESLength); //2017-01-22 Add
			if (m_payloadType == ps_payload_padding || m_payloadType == ps_payload_sps || m_payloadType == ps_payload_pps)
			{
				if (payloadType != ps_payload_padding)
				{
					m_payloadType = payloadType;
				}
			}
		
			if (bFirstPes)
			{
				bH264ParamSet = IsH264ParamSet(nakedPes.pESBuffer, nakedPes.nESLength);
				bFirstPes = false;
			}

			if (m_nextStatus == ps_ps)	//2014-07-12 Add
			{
				GetNextDts(); //2014-07-11 Add
				if (m_bFrameHeader || m_nextdts != nakedPes.dts)
				{
					if (bH264ParamSet && m_nESLength < H264_SCAN_LENGTH)	//2015-04-02 Add ĳЩPS���� H264 Sequence Parameter Set��װ��һ�������İ�
					{
						bH264ParamSet = false;
						bContinue = true;
						continue;
					}

					break;
				}				
				else
				{
					bContinue = true;
					continue;
				}
			}
			else if (m_nextStatus == ps_pes)
			{
				if (m_nextStreamID != 0xC0)
				{
					bContinue = true;
					continue;
				}
			}

		}
		else if(m_psAnalyzer.is_audio_stream_id(stream_id))
		{
			if (m_psAnalyzer.is_video_stream_id(stream_id))	//2014-09-26 Add ĳЩ��Ƶ֡��������Ƶ
			{
				break;
			}

			nakedPes.bValid = true;
			nakedPes.byType = 0xC0;
			nakedPes.pts = pts;
			nakedPes.dts = dts;
			if (nakedPes.dts == 0)
			{
				nakedPes.dts = nakedPes.pts;
			}

			//nakedPes.pESBuffer = m_pESBuffer;
			//nakedPes.nESLength = m_nESLength;

		}
		else if (status == ps_pes) //2014-07-02 Add
		{
			//nakedPes.pESBuffer = m_pESBuffer;
			//nakedPes.nESLength = m_nESLength;

			PS_PAYLOAD_TYPE payloadType = m_psAnalyzer.GetPSPayloadType((uint8_t*)pESBuffer, nESLength); //2017-01-22 Add
			if (m_payloadType == ps_payload_padding || m_payloadType == ps_payload_sps || m_payloadType == ps_payload_pps)
			{
				if (payloadType != ps_payload_padding)
				{
					m_payloadType = payloadType;
				}
			}

			if (m_nextStatus == ps_pes)
			{
				if (m_nextStreamID != 0xC0)
				{
					bContinue = true;
					continue;
				}
			}
			else if (m_nextStatus == ps_ps)	//2014-09-24 Add
			{
				GetNextDts(); //2014-07-11 Add

				if (m_nextdts == 0 && m_nPSWritePos-m_nPESIndicator < 80)	//2017-06-10 Add ����ȫ����һ������ͷ
				{
					nakedPes.bValid = false;
					break;
				}

				if (m_nextdts == 0 && bFirstNextPtsZero)	//2017-08-22 Add
				{
					bFirstNextPtsZero = false;
					continue;
				}

				if (m_bFrameHeader || m_nextdts != nakedPes.dts)
				{
					if (bH264ParamSet && m_nESLength < H264_SCAN_LENGTH)	//2015-04-02 Add ĳЩPS���� H264 Sequence Parameter Set��װ��һ�������İ�
					{
						bH264ParamSet = false;
						bContinue = true;
						continue;
					}

					break;
				}				
				else
				{
					bContinue = true;
					continue;
				}
			}
		}
	} while (bContinue);

	m_nESLength = 0;

	if (nakedPes.bValid)
	{
		memcpy(psPacket.pPSBuffer, m_pPSBuffer, m_nNextPESIndicator);
		psPacket.nPSLength = m_nNextPESIndicator;

		memmove(m_pPSBuffer, m_pPSBuffer+m_nNextPESIndicator, m_nPSWritePos-m_nNextPESIndicator);

		m_nPSWritePos -= m_nNextPESIndicator;
		m_nPESIndicator = m_nNextPESIndicator = 0;
		m_ps = (ps_header_t*)(m_pPSBuffer+m_nNextPESIndicator);
		m_pes = (pes_header_t*)(m_pPSBuffer+m_nNextPESIndicator);

		nakedPes.bIFrame = m_frameParser.IsIFrame(psPacket.pPSBuffer, psPacket.nPSLength);	
	}
	else	//2014-07-22 Add
	{
		m_nPESIndicator = m_nNextPESIndicator = 0;	
		m_status = ps_padding;

		//if (m_bLastValid)
		//{
		//	m_nMinParseLength = 10<<10; //10k;
		//}
		//else
		//{
		//	if (m_nMinParseLength < MAX_PES_LENGTH/2)
		//	{
		//		m_nMinParseLength *= 2;
		//	}			
		//}
	}

	//m_bLastValid = nakedPes.bValid;

	psPacket.bValid = nakedPes.bValid;
	psPacket.bIFrame = nakedPes.bIFrame;

	psPacket.byType = nakedPes.byType;

	psPacket.pts = nakedPes.pts;
	psPacket.dts = nakedPes.dts;

	return psPacket.bValid;
}

bool CPSParser::IsH264ParamSet(uint8_t* pBuf, uint32_t nBufSize)
{
	for (int i = 0; i < H264_SCAN_LENGTH && i < nBufSize; i++)
	{
		if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x01)	//nal_unit_type: 7-���в�����
		{
			int nal_unit_type = pBuf[i+3] & 0x1f;
			if (nal_unit_type == 0x07)
			{
				//OutputDebugString("\n ################## I Frame ################");
				return true;
			}
		}
	}

	return false;
}
