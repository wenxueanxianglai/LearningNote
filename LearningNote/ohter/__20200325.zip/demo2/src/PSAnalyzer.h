#pragma once
#include "PSStruct.h"

#define AV_RB16(x)   ((((const uint8_t*)(x))[0] << 8)|((const uint8_t*)(x))[1])


class CPSAnalyzer
{
public:
	CPSAnalyzer(void);
	~CPSAnalyzer(void);

    uint64_t ff_parse_pes_pts(const unsigned char* buf);

    uint64_t get_pts(optional_pes_header* option);

    uint64_t get_dts(optional_pes_header* option);

	bool is_ps_header(ps_header_t* ps);

	bool is_sh_header(sh_header_t* sh);

	bool is_psm_header(psm_header_t* psm);

	bool is_pes_video_header(pes_header_t* pes);

	bool is_pes_audio_header(pes_header_t* pes);

	bool is_pes_header(pes_header_t* pes);

	PSStatus pes_type(pes_header_t* pes);

	bool is_video_stream_id(uint8_t stream_id); //2015-06-23 Add (E0~EFΪ��ƵID) 
	bool is_audio_stream_id(uint8_t stream_id); //(C0~DFΪ��ƵID)

	PS_PAYLOAD_TYPE GetPSPayloadType(uint8_t* pBuf, uint32_t nBufSize);	//2016-07-14 Add

};
