#include "ESParser.h"


CESParser::CESParser(uint8_t* pPSBuffer, uint32_t nPSBufferSize, uint32_t nFrameRate)
: IH264Parser(pPSBuffer, nPSBufferSize)
, m_nDefaultFrameRate(nFrameRate)
{
	if (5 <= nFrameRate && nFrameRate <= 60)
	{
		m_nFrameSpan = 1000/nFrameRate;
	}
	else
	{
		m_nFrameSpan = 40;
	}

	Clear();

//	OutputDebug("\n ********** create ESParser");
}

CESParser::~CESParser(void)
{
}

NAKED_PES_INFO CESParser::GetAFrame()
{
	NAKED_PES_INFO nakedPes;

	if (m_iESStartPos == -1)
	{
		if (m_status != es_padding)
		{
			m_iESStartPos = m_nESIndicator;
			m_nESIndicator += NAL_HEADER_LENGTH;
		}
	}

	//static int iFrameIndex = 0;
	//if (iFrameIndex == 13)
	//{
	//	OutputDebug("\n iFrameIndex == 13");
	//}

	ESStatus status = m_status;

	ESStatus newStatus = m_esAnalyzer.GetNextStatus(m_pPSBuffer, m_nESIndicator, m_nPSWritePos);
	while (newStatus != es_padding)
	{
		m_status = newStatus;

		if (status == es_slice_idr || status == es_slice_non_idr)
		{
			if (m_status == status && m_esAnalyzer.get_first_mb_in_slice() != 0)
			{
				m_nESIndicator += NAL_HEADER_LENGTH;

				newStatus = m_esAnalyzer.GetNextStatus(m_pPSBuffer, m_nESIndicator, m_nPSWritePos);
				continue;
			}

			nakedPes.bValid = true;
			nakedPes.byType = 0xE0;
			if (status == es_slice_idr)
			{
				nakedPes.bIFrame = true;
			}

			nakedPes.pts = m_nLastFrameTick*90;
			m_nLastFrameTick += m_nFrameSpan;

			nakedPes.dts = nakedPes.pts;
			m_nESLength = m_nESIndicator-m_iESStartPos;
			if (m_nESLength <= MAX_ES_LENGTH)
			{
				memcpy(m_pESBuffer, m_pPSBuffer+m_iESStartPos, m_nESLength);
			}
			else
			{
				nakedPes.bValid = false;
			}

			memmove(m_pPSBuffer, m_pPSBuffer+m_nESIndicator, m_nPSWritePos-m_nESIndicator);
			m_nPSWritePos -= m_nESLength;
			m_iESStartPos = 0;
			m_nESIndicator = NAL_HEADER_LENGTH;

			nakedPes.pESBuffer = m_pESBuffer;
			nakedPes.nESLength = m_nESLength;
			
			//static int iFrameIndex = 0;
		/*	iFrameIndex++;
			char tempBuf[600];
			ZeroMemory(tempBuf, sizeof(tempBuf));
			sprintf(tempBuf, "\n %d\t %d\t\t", iFrameIndex, nakedPes.nESLength);
			OutputDebugString(tempBuf);

			for (int j = 0; j < 64; j++)
			{
				sprintf(tempBuf+3*j, "%02X ", (uint8_t)nakedPes.pESBuffer[j]);
			}
			OutputDebugString(tempBuf);*/

			break;
		}
		
		status = m_status;
		if (m_iESStartPos == -1)
		{
			m_iESStartPos = m_nESIndicator;
		}

		m_nESIndicator += NAL_HEADER_LENGTH;

		newStatus = m_esAnalyzer.GetNextStatus(m_pPSBuffer, m_nESIndicator, m_nPSWritePos);
	}

	return nakedPes;
}

void CESParser::Clear()
{
	m_nPSWritePos = 0;
	m_nESIndicator = 0;

	m_iESStartPos = -1;

	m_nLastFrameTick = 0;

	m_status = es_padding;

}
