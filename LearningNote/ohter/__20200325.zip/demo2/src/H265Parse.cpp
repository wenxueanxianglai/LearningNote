﻿#include <stddef.h>
#include "H265Parse.h"

// --- core NAL Unit implementation ------------------------------

NALUnit::NALUnit()
    : m_pStart(NULL),
    m_cBytes(0)
{
    m_pStartCodeStart = NULL;
    m_idx = 0;
    m_nBits = 0;
    m_byte = 0;
    m_cZeros = 0;
    m_startCodeSize = 0;
}

bool NALUnit::GetStartCode(const uint8_t*& pBegin, const uint8_t*& pStart, int32_t& cRemain)
{
    // start code is any number of 00 followed by 00 00 01
    // We need to record the first 00 in pBegin and the first byte
    // following the startcode in pStart.
    // if no start code is found, pStart and cRemain should be unchanged.

    const uint8_t* pThis = pStart;
    int32_t cBytes = cRemain;

    pBegin = NULL;
    //支持nalu数据start code为 00 00 01和00 00 00 01两种情况
    while (cBytes >= 3)
    {
        if ((pThis[0] == 0) && (cBytes >= 4))
        {
            // remember first 00
            if ((pThis[1] == 0) &&
                (pThis[2] == 0) &&
                (pThis[3] == 1))
            {
                pBegin = pThis;
                // point to type byte of NAL unit
                pStart = pThis + 4;
                cRemain = cBytes - 4;
                m_startCodeSize = 4;
                return true;
            }
        }

        if (pThis[0] == 0)
        {
            if ((pThis[1] == 0) &&
                (pThis[2] == 1))
            {
                pBegin = pThis;
                pStart = pThis + 3;
                cRemain = cBytes - 3;
                m_startCodeSize = 3;
                return true;
            }
        }

        cBytes--;
        pThis++;
    }
    return false;
}

bool NALUnit::Parse(const uint8_t* pBuffer, int32_t cSpace, int32_t LengthSize, bool bEnd)
{
    // if we get the start code but not the whole
    // NALU, we can return false but still have the length property valid
    m_cBytes = 0;

    ResetBitstream();

    if (LengthSize > 0)
    {
        m_pStartCodeStart = pBuffer;

        if (LengthSize > cSpace)
        {
            return false;
        }

        m_cBytes = 0;
        for (int32_t i = 0; i < LengthSize; i++)
        {
            m_cBytes <<= 8;
            m_cBytes += *pBuffer++;
        }

        if ((m_cBytes + LengthSize) <= cSpace)
        {
            m_pStart = pBuffer;
            return true;
        }
    }
    else {
        // this is not length-delimited: we must look for start codes
        const uint8_t* pBegin;
        if (GetStartCode(pBegin, pBuffer, cSpace))
        {
            m_pStart = pBuffer;
            m_pStartCodeStart = pBegin;

            // either we find another startcode, or we continue to the
            // buffer end (if this is the last block of data)
            if (GetStartCode(pBegin, pBuffer, cSpace))
            {
                m_cBytes = (int32_t)(pBegin - m_pStart);
                return true;
            }
            else if (bEnd)
            {
                // current element extends to end of buffer
                m_cBytes = cSpace;
                return true;
            }
        }
    }
    return false;
}

// bitwise access to data
void NALUnit::ResetBitstream()
{
    m_idx = 0;
    m_nBits = 0;
    m_cZeros = 0;
}

void NALUnit::Skip(int32_t nBits)
{
    if (nBits < m_nBits)
    {
        m_nBits -= nBits;
    }
    else
    {
        nBits -= m_nBits;
        while (nBits >= 8)
        {
            GetBYTE();
            nBits -= 8;
        }
        if (nBits)
        {
            m_byte = GetBYTE();
            m_nBits = 8;
            m_nBits -= nBits;
        }
    }
}

// get the next byte, removing emulation prevention bytes
uint8_t NALUnit::GetBYTE()
{
    if (m_idx >= m_cBytes)
    {
        return 0;
    }

    uint8_t b = 0;
    if (m_pStart)
        b = m_pStart[m_idx++];

    // to avoid start-code emulation, a byte 0x03 is inserted
    // after any 00 00 pair. Discard that here.
    if (b == 0)
    {
        m_cZeros++;
        if ((m_idx < m_cBytes) && (m_cZeros == 2) && m_pStart && (m_pStart[m_idx] == 0x03))
        {
            m_idx++;
            m_cZeros = 0;
        }
    }
    else {
        m_cZeros = 0;
    }
    return b;
}

uint32_t NALUnit::GetBit()
{
    if (m_nBits == 0)
    {
        m_byte = GetBYTE();
        m_nBits = 8;
    }
    m_nBits--;
    return (m_byte >> m_nBits) & 0x1;
}

uint32_t NALUnit::GetWord(int32_t nBits)
{
    uint32_t u = 0;
    while (nBits > 0)
    {
        u <<= 1;
        u |= GetBit();
        nBits--;
    }
    return u;
}

NALUnitRBSP::NALUnitRBSP(NALUnit &nal)
{
    int i = 0, len = 0;
    const uint8_t *src = nal.Start();
    int src_len = nal.Length();

    rbsp = new uint8_t[src_len];

    /* nal header */
    while (i < 2 && i < src_len)
        rbsp[len++] = src[i++];

    while (i + 2 < src_len)
        if (!src[i] && !src[i + 1] && src[i + 2] == 3) {
            rbsp[len++] = src[i++];
            rbsp[len++] = src[i++];
            i++; // remove emulation_prevention_three_byte
        }
        else
            rbsp[len++] = src[i++];

    while (i < src_len)
        rbsp[len++] = src[i++];

    mSize = len;
    mSizeInBit = mSize * 8;

    mBit = 0;
}

NALUnitRBSP::~NALUnitRBSP()
{
    delete rbsp;
}

int NALUnitRBSP::SkipBits(int bits)
{
    if (mBit + bits < mSizeInBit) {
        mBit += bits;
        return bits;
    }
    else {
        return (bits + 1);
    }
}

int NALUnitRBSP::ResetBit(int bit)
{
    if (bit >= 0 && bit < mSizeInBit) {
        mBit = bit;
        return mBit;
    }
    else {
        return (bit + 1);
    }
}

int NALUnitRBSP::GetBit()
{
    return mBit;
}


int NALUnitRBSP::GetBitLeft()
{
    return mSizeInBit - mBit;
}

uint32_t NALUnitRBSP::ShowBits(int bits)
{
    int bit;
    uint32_t r = 0;
    if (mBit + bits >= mSizeInBit)
        return 0;

    if (bits > 32)
        return 0;

    bit = mBit;
    while (bits > 0) {
        r <<= 1;
        r |= (rbsp[bit >> 3] >> (7 - bit & 7)) & 0x1;
        bit++;
        bits--;
    }

    return r;
}

uint64_t NALUnitRBSP::ShowBitsLong(int bits)
{
    int bit;
    uint64_t r = 0;
    if (mBit + bits >= mSizeInBit)
        return 0;

    if (bits > 64)
        return 0;

    bit = mBit;
    while (bits > 0) {
        r <<= 1;
        r |= (rbsp[bit >> 3] >> (7 - bit & 7)) & 0x1;
        bit++;
        bits--;
    }

    return r;
}

uint32_t NALUnitRBSP::GetBits(int bits)
{
    uint32_t ret;
    ret = ShowBits(bits);
    SkipBits(bits);
    return ret;
}

uint64_t NALUnitRBSP::GetBitsLong(int bits)
{
    uint64_t ret;
    ret = ShowBitsLong(bits);
    SkipBits(bits);
    return ret;
}

unsigned NALUnitRBSP::GetUEGolomb()
{
    unsigned buf, log;
    unsigned ret;
    buf = ShowBits(32);
    log = 0;
    while (buf >>= 1)
        log++;
    log = 31 - log;
    SkipBits(log);
    ret = GetBits(log + 1) - 1;
    //SkipBits(log + 1);
    return ret;
}

int NALUnitRBSP::GetSEGolomb()
{
    unsigned int buf = GetUEGolomb();
    int sign;

    sign = (buf & 1) - 1;
    return ((buf >> 1) ^ sign) + 1;
}

/* copy from ffmpeg:libavformat:hevc.c */
void hvcc_update_ptl(HVCCProfileTierLevel *ptl, HEVCDecoderConfigurationRecord& hvcc)
{
    /*
 * The value of general_profile_space in all the parameter sets must be
 * identical.
 */
    hvcc.general_profile_space = ptl->profile_space;

    /*
     * The level indication general_level_idc must indicate a level of
     * capability equal to or greater than the highest level indicated for the
     * highest tier in all the parameter sets.
     */
    if (hvcc.general_tier_flag < ptl->tier_flag)
        hvcc.general_level_idc = ptl->level_idc;
    else if (hvcc.general_level_idc < ptl->level_idc)
        hvcc.general_level_idc = ptl->level_idc;

    /*
     * The tier indication general_tier_flag must indicate a tier equal to or
     * greater than the highest tier indicated in all the parameter sets.
     */
    if (hvcc.general_tier_flag < ptl->tier_flag)
        hvcc.general_tier_flag = ptl->tier_flag;

    /*
     * The profile indication general_profile_idc must indicate a profile to
     * which the stream associated with this configuration record conforms.
     *
     * If the sequence parameter sets are marked with different profiles, then
     * the stream may need examination to determine which profile, if any, the
     * entire stream conforms to. If the entire stream is not examined, or the
     * examination reveals that there is no profile to which the entire stream
     * conforms, then the entire stream must be split into two or more
     * sub-streams with separate configuration records in which these rules can
     * be met.
     *
     * Note: set the profile to the highest value for the sake of simplicity.
     */
    if (hvcc.general_profile_idc < ptl->profile_idc)
        hvcc.general_profile_idc = ptl->profile_idc;

    /*
     * Each bit in general_profile_compatibility_flags may only be set if all
     * the parameter sets set that bit.
     */
    hvcc.general_profile_compatibility_flags &= ptl->profile_compatibility_flags;

    /*
     * Each bit in general_constraint_indicator_flags may only be set if all
     * the parameter sets set that bit.
     */
    hvcc.general_constraint_indicator_flags &= ptl->constraint_indicator_flags;
}
