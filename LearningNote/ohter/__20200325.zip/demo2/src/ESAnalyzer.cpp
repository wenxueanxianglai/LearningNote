#include "ESAnalyzer.h"

CESAnalyzer::CESAnalyzer(void)
: m_first_mb_in_slice(0)
{
}

CESAnalyzer::~CESAnalyzer(void)
{
}

ESStatus CESAnalyzer::GetNextStatus(uint8_t* pPSBuffer, uint32_t& nESIndicator, uint32_t nPSWritePos)
{
	if (nPSWritePos <= NAL_SLICE_HEAD_LENGTH)
	{
		return es_padding;
	}

	ESStatus status = es_padding;
	int nal_unit_type = 0;
	for(; nESIndicator < nPSWritePos-NAL_SLICE_HEAD_LENGTH; nESIndicator++) //-8: NAL header + slice parse
	{
		if (pPSBuffer[nESIndicator] == 0x00 && pPSBuffer[nESIndicator+1] == 0x00 
			&& pPSBuffer[nESIndicator+2] == 0x01)	//nal_unit_type
		{
			nal_unit_type = pPSBuffer[nESIndicator+3] & 0x1f;
			switch (nal_unit_type)
			{
			case 1:
				status = es_slice_non_idr;
				calc_first_mb_in_slice(pPSBuffer+nESIndicator+4);
				break;

			case 5:
				status = es_slice_idr;
				calc_first_mb_in_slice(pPSBuffer+nESIndicator+4);
				break;

			case 7:
				status = es_sps;
				break;

			case 8:
				status = es_pps;
				break;

			default:
				continue;
				break;
			}

			if (nESIndicator > 0 && pPSBuffer[nESIndicator-1] == 0x00)
			{
				nESIndicator--;
			}

			break;	
		}
	}

	return status;
}

void CESAnalyzer::calc_first_mb_in_slice(uint8_t* pStartPos) //Exp-Golomb codes
{
	m_bitBuffer.set_buf(pStartPos, 4, false);

	int leadingZeroBits = 0;
	for (int i = 0; i < 32; i++)
	{
		if (m_bitBuffer.get_bits(1))
		{
			break;
		}

		leadingZeroBits++;
	}

	int read_bits_of_leadingZeroBits = 0;
	if (leadingZeroBits > 0)
	{
		read_bits_of_leadingZeroBits = m_bitBuffer.get_bits(leadingZeroBits);
	}

	m_first_mb_in_slice = (1<<leadingZeroBits) - 1 + read_bits_of_leadingZeroBits;
}
