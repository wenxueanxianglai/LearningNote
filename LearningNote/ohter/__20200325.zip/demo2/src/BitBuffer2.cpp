#include "BitBuffer2.h"

uint32_t BIT_MASK[] = {   
	0x0,0x1,0x3,0x7,0xf,0x1f,0x3f,0x7f,0xff,   
		0x1ff,0x3ff,0x7ff,0xfff,0x1fff,0x3fff,0x7fff,0xffff,   
		0x1ffff,0x3ffff,0x7ffff,0xfffff,0x1fffff,0x3fffff,0x7fffff,0xffffff,   
		0x1ffffff,0x3ffffff,0x7ffffff,0xfffffff,0x1fffffff,0x3fffffff,0x7fffffff,0xffffffff};   


CBitBuffer2::CBitBuffer2(void)
: m_bitpos(0)   
, m_bitval(0)   
, m_bitbuf(NULL)
{
}

CBitBuffer2::~CBitBuffer2(void)
{
}

void CBitBuffer2::set_buf(uint8_t* buf, int bufsize, bool clear/* = true*/)   
{   
	m_bitpos = 0;   
	m_bitbuf = buf;   
	m_bitval = (m_bitbuf[0] << 24) | (m_bitbuf[1] << 16) | (m_bitbuf[2] << 8) | m_bitbuf[3];   
	if (clear)   
		memset(m_bitbuf, 0, bufsize);   
}   

void CBitBuffer2::set_bits(uint32_t val, int bits)   
{   
	val &= BIT_MASK[bits];   

	while (bits > 0)   
	{   
		int bitsleft = (8 - (m_bitpos & 7));   
		if (bits >= bitsleft)   
		{   
			m_bitbuf[m_bitpos >> 3] |= val >> (bits - bitsleft);   
			m_bitpos += bitsleft;   
			bits -= bitsleft;   
			val &= BIT_MASK[bits];   
		}   
		else   
		{   
			m_bitbuf[m_bitpos >> 3] |= val << (bitsleft - bits);   
			m_bitpos += bits;   
			bits = 0;   
		}   
	}   
}   

void CBitBuffer2::set_bit_pos(uint32_t newpos)   
{   
	m_bitpos = newpos;   

	uint32_t pos = m_bitpos >> 5;   
	m_bitval = (m_bitbuf[pos] << 24) | (m_bitbuf[pos + 1] << 16) | (m_bitbuf[pos + 2] << 8) | m_bitbuf[pos + 3];   
}   

void CBitBuffer2::set_byte_pos(uint32_t newpos)   
{   
	set_bit_pos(newpos << 3);   
}   

 uint32_t CBitBuffer2::get_bits(int bits)   
{   
	uint32_t val;   
	int left = 32 - (m_bitpos & 31);   

	if (bits < left)   
	{   
		val = (m_bitval >> (left - bits)) & BIT_MASK[bits];   
		m_bitpos += bits;   
	}   
	else   
	{   
		val = (m_bitval & BIT_MASK[left]) << (bits - left);   
		m_bitpos += left;   
		bits -= left;   

		int pos = m_bitpos >> 3;   
		m_bitval = (m_bitbuf[pos] << 24) | (m_bitbuf[pos + 1] << 16) | (m_bitbuf[pos + 2] << 8) | m_bitbuf[pos + 3];   

		if (bits > 0)   
		{   
			val |= (m_bitval >> (32 - bits)) & BIT_MASK[bits];   
			m_bitpos += bits;   
		}   
	}   

	return val;   
}  
