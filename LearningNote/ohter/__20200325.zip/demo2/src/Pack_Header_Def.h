
#ifndef __HEADER_PACK_HEADER_DEF_H__
#define __HEADER_PACK_HEADER_DEF_H__

#include <stdint.h>
#include "crc32.h"

#ifdef _WIN32
typedef unsigned __int64 UINT64;
#else
typedef long long UINT64;
#endif

#pragma pack(1)

typedef struct PS_HEADER_tag
{
	unsigned char pack_start_code[4];		//'0x000001BA'

	unsigned char system_clock_reference_base21:2;
	unsigned char marker_bit:1;
	unsigned char system_clock_reference_base1:3;
	unsigned char fix_bit:2;				//'01'
	
	unsigned char system_clock_reference_base22;

	unsigned char system_clock_reference_base31:2;
	unsigned char marker_bit1:1;
	unsigned char system_clock_reference_base23:5;

	unsigned char system_clock_reference_base32;

	unsigned char system_clock_reference_extension1:2;
	unsigned char marker_bit2:1;
	unsigned char system_clock_reference_base33:5;	//system_clock_reference_base 33bit

	unsigned char marker_bit3:1;
	unsigned char system_clock_reference_extension2:7; //system_clock_reference_extension 9bit
	
	unsigned char program_mux_rate1;

	unsigned char program_mux_rate2;

	unsigned char marker_bit5:1;
	unsigned char marker_bit4:1;
	unsigned char program_mux_rate3:6;

	unsigned char pack_stuffing_length:3;
	unsigned char reserved:5;
	
	PS_HEADER_tag()
	{
		pack_start_code[0] = 0x00;
		pack_start_code[1] = 0x00;
		pack_start_code[2] = 0x01;
		pack_start_code[3] = 0xBA;
		fix_bit = 0x01;	
		marker_bit = 0x01;
		marker_bit1 = 0x01;
		marker_bit2 = 0x01;
		marker_bit3 = 0x01;
		marker_bit4 = 0x01;
		marker_bit5 = 0x01;
		reserved = 0x1F;
		pack_stuffing_length = 0x00;
		system_clock_reference_extension1 = 0;
		system_clock_reference_extension2 = 0;
	}
	
	void getSystem_clock_reference_base(UINT64 &_ui64SCR)
	{
		_ui64SCR = (system_clock_reference_base1 << 30) | (system_clock_reference_base21 << 28)
			| (system_clock_reference_base22 << 20) | (system_clock_reference_base23 << 15)
			| (system_clock_reference_base31 << 13) | (system_clock_reference_base32 << 5)
			| (system_clock_reference_base33);

	}

	void setSystem_clock_reference_base(UINT64 _ui64SCR)
	{
		system_clock_reference_base1 = (_ui64SCR >> 30) & 0x07;
		system_clock_reference_base21 = (_ui64SCR >> 28) & 0x03;
		system_clock_reference_base22 = (_ui64SCR >> 20) & 0xFF;
		system_clock_reference_base23 = (_ui64SCR >> 15) & 0x1F;
		system_clock_reference_base31 = (_ui64SCR >> 13) & 0x03;
		system_clock_reference_base32 = (_ui64SCR >> 5) & 0xFF;
		system_clock_reference_base33 = _ui64SCR & 0x1F;
	}

	void getProgram_mux_rate(unsigned int &_uiMux_rate)
	{
		_uiMux_rate = (program_mux_rate1 << 14) | (program_mux_rate2 << 6) | program_mux_rate3;
	}

	void setProgram_mux_rate(unsigned int _uiMux_rate)
	{
		program_mux_rate1 = (_uiMux_rate >> 14) & 0xFF;
		program_mux_rate2 = (_uiMux_rate >> 6) & 0xFF;
		program_mux_rate3 = _uiMux_rate & 0x3F;
	}
		
}*pPS_HEADER_tag;

typedef struct PES_HEADER_tag
{
	unsigned char	packet_start_code_prefix[3];
	unsigned char	stream_id;
	unsigned char	PES_packet_length[2];

	unsigned char	original_or_copy:1;
	unsigned char	copyright:1;
	unsigned char	data_alignment_indicator:1;
	unsigned char	PES_priority:1;
	unsigned char	PES_scrambling_control:2;
	unsigned char	fix_bit:2;

	unsigned char	PES_extension_flag:1;
	unsigned char	PES_CRC_flag:1;
	unsigned char	additional_copy_info_flag:1;
	unsigned char	DSM_trick_mode_flag:1;
	unsigned char	ES_rate_flag:1;
	unsigned char	ESCR_flag:1;
	unsigned char	PTS_DTS_flags:2;

	unsigned char	PES_header_data_length;

	PES_HEADER_tag()
	{
		packet_start_code_prefix[0] = 0x00;
		packet_start_code_prefix[1] = 0x00;
		packet_start_code_prefix[2] = 0x01;

		PES_packet_length[0] = 0x00;
		PES_packet_length[1] = 0x00;

		stream_id = 0xE0;
		fix_bit = 0x02;
	}

}*pPES_HEADER_tag; //9

typedef struct PTS_tag
{
	unsigned char marker_bit:1;
	unsigned char PTS1:3;
	unsigned char fix_bit:4;

	unsigned char PTS21;

	unsigned char marker_bit1:1;
	unsigned char PTS22:7;

	unsigned char PTS31; 

	unsigned char marker_bit2:1;
	unsigned char PTS32:7;

	PTS_tag()
	{
		//fix_bit = 0x02;
		fix_bit = 0x03;			
		marker_bit = 0x01;
		marker_bit1 = 0x01;
		marker_bit2 = 0x01;
	}

	void getPTS(UINT64 &_ui64PTS)
	{
		_ui64PTS = (PTS1 << 30) | (PTS21 << 22)
			| (PTS22 << 15) | (PTS31 << 7) | (PTS32);
		
	}

	void setPTS(UINT64 _ui64PTS)
	{
		PTS1 = (_ui64PTS >> 30) & 0x07;
		PTS21 = (_ui64PTS >> 22) & 0xFF;
		PTS22 = (_ui64PTS >> 15) & 0x7F;
		PTS31 = (_ui64PTS >> 7) & 0xFF;
		PTS32 = _ui64PTS & 0x7F;
	}
}*pPTS_tag;

typedef struct PSH_tag
{
	unsigned char system_header_start_code[4]; //'0x000001BB'

	unsigned char header_length[2];            //16 uimsbf

	//unsigned char marker_bit1:1;  //1  bslbf
	//unsigned int rate_bound:22;   //22 uimsbf	
	//unsigned char marker_bit2:1;  //1 bslbf
	unsigned char rate_bound[3];

	unsigned char CSPS_flag : 1;     //1 bslbf
	unsigned char fixed_flag : 1;    //1 bslbf
	unsigned char audio_bound : 6;   //6 uimsbf	

	unsigned char video_bound : 5;             // uimsbf
	unsigned char marker_bit3 : 1;             // bslbf
	unsigned char system_video_lock_flag : 1;  // bslbf
	unsigned char system_audio_lock_flag:1;  // bslbf	

	unsigned char reserved_bits : 7;                //bslbf
	unsigned char packet_rate_restriction_flag:1; //bslbf
	
	//unsigned char reserved[6];

	PSH_tag()
	{
		system_header_start_code[0]=0x00;
		system_header_start_code[1]=0x00;
		system_header_start_code[2]=0x01;
		system_header_start_code[3]=0xBB;

		header_length[0] = 0x00;
		header_length[1] = 0x06;

		/*marker_bit1 = 0x01;
		rate_bound = 0x00;
		marker_bit2 = 0x01;*/
		rate_bound[0] = 0x80;
		rate_bound[1] = 0x00;
		rate_bound[2] = 0x01;


		audio_bound = 0x00;
		fixed_flag = 0x00;
		CSPS_flag = 0x00;

		system_audio_lock_flag = 0x00;
		system_video_lock_flag = 0x00;
		marker_bit3 = 0x01;
		video_bound = 0x00;

		reserved_bits = 0x7F;
		packet_rate_restriction_flag = 0x00;
		
	}

}*pPSH_tag; //12

typedef struct PSM_tag
{
	unsigned char packet_start_code_prefix[4]; //'0x000001BC'	

	unsigned char program_stream_map_length[2];
	
	unsigned char program_stream_map_version : 5;
	unsigned char reserved1 : 2;
	unsigned char current_next_indicator : 1;	

	unsigned char marker_bit : 1;
	unsigned char reserved2 : 7;

	unsigned char program_stream_info_length[2];

	unsigned char elementary_stream_map_length[2];

	//video
	unsigned char video_stream_type;
	unsigned char video_elementary_stream_id;
	unsigned char video_elementary_stream_info_length[2];

	//audio
	unsigned char audio_stream_type;
	unsigned char audio_elementary_stream_id;
	unsigned char audio_elementary_stream_info_length[2];	
	
	unsigned char CRC_32[4];

	PSM_tag()
	{
		packet_start_code_prefix[0] = 0x00;
		packet_start_code_prefix[1] = 0x00;
		packet_start_code_prefix[2] = 0x01;	
		packet_start_code_prefix[3] = 0xBC;

		program_stream_map_length[0] = 0x00;
		program_stream_map_length[1] = 0x12;

		program_stream_map_version = 0x01;
		reserved1 = 0x03;
		current_next_indicator = 0x01;	
		
		marker_bit = 0x01;
		reserved2 = 0x7F;

		program_stream_info_length[0] = 0x00;
		program_stream_info_length[1] = 0x00;

		elementary_stream_map_length[0] = 0x00;
		elementary_stream_map_length[1] = 0x08;		

		//video
		video_stream_type = 0x1B;
		video_elementary_stream_id = 0xE0;
		video_elementary_stream_info_length[0] = 0x00;
		video_elementary_stream_info_length[1] = 0x00;

		//audio
		audio_stream_type = 0x90;
		audio_elementary_stream_id = 0xC0;
		audio_elementary_stream_info_length[0] = 0;
		audio_elementary_stream_info_length[1] = 0;

		CRC_32[0] = 0x31;
		CRC_32[1] = 0xE8;
		CRC_32[2] = 0xCA;
		CRC_32[3] = 0xB9;		
	}

	void crc32()
	{
        uint32_t crc = crc_init();
 		crc = crc_update(crc, this, 20);
 		crc = crc_finalize(crc);

		CRC_32[0] = crc;
		CRC_32[1] = crc >> 8;
		CRC_32[2] = crc >> 16;
		CRC_32[3] = crc >> 24;
	}

}*pPSM_tag; //24

#pragma pack()

//typedef unsigned __int64   uint64_t;

#define PS_HDR_LEN  14  
//#define SYS_HDR_LEN 15    //��audioʱ��18���ֽ�
#define SYS_HDR_LEN 18    //��audioʱ��18���ֽ�  2017-10-31 modify
#define PSM_HDR_LEN 24  
#define PES_HDR_LEN 19  
#define RTP_HDR_LEN 12  
/*** 
 *@remark:  ����������ݰ���λһ��һ����ѹ������ 
 *@param :  buffer   [in]  ѹ�����ݵ�buffer 
 *          count    [in]  ��Ҫѹ������ռ��λ�� 
 *          bits     [in]  ѹ�����ֵ 
 */  
#define bits_write(buffer, count, bits)\
{\
	bits_buffer_s *p_buffer = (buffer);\
	int i_count = (count);\
	uint64_t i_bits = (bits);\
	while( i_count > 0 )\
{\
	i_count--;\
	if( ( i_bits >> i_count )&0x01 )\
{\
	p_buffer->p_data[p_buffer->i_data] |= p_buffer->i_mask;\
}\
else\
{\
	p_buffer->p_data[p_buffer->i_data] &= ~p_buffer->i_mask;\
}\
	p_buffer->i_mask >>= 1;         /*������һ���ֽڵ�һλ�󣬲����ڶ�λ*/\
	if( p_buffer->i_mask == 0 )     /*ѭ����һ���ֽڵ�8λ�����¿�ʼ��һλ*/\
{\
	p_buffer->i_data++;\
	p_buffer->i_mask = 0x80;\
}\
}\
}  

struct bits_buffer_s
{
	int i_size;
	int i_data;
	int i_mask;
	unsigned char * p_data;
};

#endif
