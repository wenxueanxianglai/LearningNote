#ifndef QUICK_LOG_H
#define QUICK_LOG_H


#include <stdio.h>

//#define USE_EXTEND            1
//#define USE_FNAME_WITH_TIME   1
#define USE_USER_CFGNAME        ".quickcfg"

#define QC_LOG_NONE    0x00
#define QC_LOG_DEBUG   0x01
#define QC_LOG_INFO    0x02
#define QC_LOG_WARN    0x04
#define QC_LOG_ERROR   0x08
#define QC_LOG_FATAL   0x10
#define QC_LOG_ALL     0xFF

#ifdef _WIN32
#define __QC_FUNC__  __FUNCTION__
#else
#define __QC_FUNC__  __PRETTY_FUNCTION__
#endif

#define QCLOG(level, ...) qc_log(level, __FILE__, __LINE__, __QC_FUNC__, ##__VA_ARGS__)

#ifdef __cplusplus
extern "C" {
#endif

    int qc_init(const char *fdir, const char *fname, int fnum, int fsize_mb, int outflag);
    int qc_log(int level, const char *file, int line, const char *func, const char *fmt, ...);
	FILE *qc_getfd();

#ifdef __cplusplus
};
#endif


#endif // QUICK_LOG_H
