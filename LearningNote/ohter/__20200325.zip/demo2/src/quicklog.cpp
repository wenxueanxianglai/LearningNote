#include "quicklog.h"
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/timeb.h>
#ifdef _WIN32
#include <direct.h>
#include <io.h>
#include <Windows.h>
#pragma warning(once : 4267)
#pragma warning(once : 4996)
#else
#include <dirent.h>
#include <pthread.h>
#include <unistd.h>
#endif

#define QC_PATH_MAX 256
#define QC_NAME_MAX 128

#ifdef _WIN32
#define QC_PATH_SEPCHAR '\\'
#define QC_PATH_SEPSTR "\\"
#define QC_ACCESS(s) access(s, 0)
#define QC_MKDIR(s) mkdir(s);
#define QC_SNPRINTF _snprintf
#define QC_LOCK CRITICAL_SECTION
#else
#define QC_PATH_SEPCHAR '/'
#define QC_PATH_SEPSTR "/"
#define QC_ACCESS(s) access(s, F_OK)
#define QC_MKDIR(s) mkdir(s, 0755);
#define QC_SNPRINTF snprintf
#define QC_LOCK pthread_mutex_t
#endif

struct qc_fname {
    char process[QC_NAME_MAX];
    char user[QC_NAME_MAX];
    char create_time[QC_NAME_MAX];
    char ext[QC_NAME_MAX];
    int index;
};

struct qc_data {
    FILE *fstream;
    char cfgpath[QC_PATH_MAX];
    char dir[QC_PATH_MAX];
    struct qc_fname name;
    int file_num;
    int fsize_max;
    int outflag; // 0;file 1:console 2:all
    char earliest_path[QC_PATH_MAX];
    time_t earliest_ctime;
    int max_findex;
    int real_fnum;
    QC_LOCK lock;
    int is_inited;
} g_data;

static void
qc_lock_alloc(QC_LOCK *lock)
{
#ifdef _WIN32
    InitializeCriticalSection(lock);
#else
    pthread_mutex_init(lock, NULL);
#endif
}

static void
qc_lock_free(QC_LOCK *lock)
{
#ifdef _WIN32
    DeleteCriticalSection(lock);
#else
    pthread_mutex_destroy(lock);
#endif
}

static void
qc_lock_enter(QC_LOCK *lock)
{
#ifdef _WIN32
    EnterCriticalSection(lock);
#else
    pthread_mutex_lock(lock);
#endif
}

static void
qc_lock_leave(QC_LOCK *lock)
{
#ifdef _WIN32
    LeaveCriticalSection(lock);
#else
    pthread_mutex_unlock(lock);
#endif
}

static const char *
qc_path_onlyname(const char *path)
{
    const char *name = strrchr(path, QC_PATH_SEPCHAR);
    if (name)
        return (name + 1);
    return path;
}

static void
qc_path_onlydir(const char *path, char *dir, int size)
{
    strcpy(dir, path);
    char *end = strrchr(dir, QC_PATH_SEPCHAR);
    if (end)
        *end = '\0';
}

static unsigned int
qc_get_current_process_id()
{
#ifdef _WIN32
    return (unsigned int)GetCurrentProcessId();
#else
    return (unsigned int)getpid();
#endif
}

static void
qc_get_current_process_path(char *path, int size)
{
#ifdef _WIN32
    GetModuleFileNameA(NULL, path, size);
#else
    FILE *f = NULL;
    char *p = NULL;
    char cmd[32];

    sprintf(cmd, "readlink /proc/%d/exe", getpid());
    f = popen(cmd, "r");
    if (NULL == f)
        return;

    fgets(path, size, f);
    p = strrchr(path, '\n');
    if (p)
        *p = '\0';
    pclose(f);
#endif
}

static void
qc_get_current_process_name(char *name, int size)
{
    char path[QC_PATH_MAX] = {0};
    qc_get_current_process_path(path, sizeof(path));
    strcpy(name, qc_path_onlyname(path));
}

static unsigned int
gc_get_current_thread_id()
{
#ifdef _WIN32
    return (unsigned int)GetCurrentThreadId();
#else
    return (unsigned int)pthread_self();
#endif
}

static void
qc_get_work_dir(char *dir, int size)
{
#ifdef _WIN32
    GetCurrentDirectoryA(size, dir);
#else
    getcwd(dir, size);
#endif
}

static char *
qc_malloc_file_buf(const char *path)
{
    FILE *file = NULL;
    char *buffer = NULL;
    struct stat st;

    file = fopen(path, "rb");
    if (NULL != file) {
        stat(path, &st);
        buffer = (char *)malloc(st.st_size + 1);
        buffer[st.st_size] = 0;
        fread(buffer, sizeof(char), st.st_size, file);
        fclose(file);
    }
    return buffer;
}

static void
qc_free_file_buf(const char *buffer)
{
    free((char *)buffer);
}

static void
qc_revise_ret_string(char *retString)
{
    int index;
    index = strspn(retString, " ");
    if (0 < index)
        memmove(retString, retString + index, strlen(retString + index) + 1);
    for (index = strlen(retString) - 1; index >= 0; index--) {
        if (' ' == retString[index])
            retString[index] = 0;
        else
            break;
    }
}

static int
qc_get_profile_string(const char *appName, const char *keyName, const char *defaultValue,
    char *retString, int retSize, const char *filePath)
{
    char *fileBuff = NULL;
    char *appStart = NULL, *appEnd = NULL;
    char *keyStart = NULL;
    char *valueStart = NULL, *valueEnd = NULL;
    char app[32];
    int retLen = -1;

    if (NULL == appName || NULL == keyName || NULL == filePath)
        return retLen;

    sprintf(app, "[%s]", appName);
    fileBuff = qc_malloc_file_buf(filePath);
    if (NULL != fileBuff) {
        appStart = strstr(fileBuff, app);
        if (NULL != appStart) {
            appEnd = strchr(appStart + 1, '[');
            keyStart = strstr(appStart, keyName);
            if ((NULL != keyStart && NULL != appEnd && keyStart < appEnd) ||
                (NULL != keyStart && NULL == appEnd)) {
                valueStart = strchr(keyStart, '=');
                valueEnd = strpbrk(keyStart, "\r\n");
                if (NULL != valueStart && NULL == valueEnd) {
                    retLen = strcspn(valueStart, "\r\n");
                    if (1 == retLen)
                        strcpy(retString, "");
                    else {
                        valueStart++;
                        retLen--;
                        if (retSize > retLen) {
                            strncpy(retString, valueStart, retLen);
                            retString[retLen] = 0;
                            qc_revise_ret_string(retString);
                            retLen = strlen(retString);
                        } else
                            retLen = -1;
                    }
                } else if (NULL != valueStart && NULL != valueEnd && 0 < (valueEnd - valueStart)) {
                    valueStart++;
                    retLen = valueEnd - valueStart;
                    if (retSize > retLen) {
                        strncpy(retString, valueStart, retLen);
                        retString[retLen] = 0;
                        qc_revise_ret_string(retString);
                        retLen = strlen(retString);
                    } else
                        retLen = -1;
                }
            }
        }
        qc_free_file_buf(fileBuff);
    }
    if (-1 == retLen) {
        if (NULL == defaultValue) {
            strcpy(retString, "");
            retLen = 0;
        } else if (retSize > strlen(defaultValue)) {
            strcpy(retString, defaultValue);
            qc_revise_ret_string(retString);
            retLen = strlen(retString);
        }
    }
    return retLen;
}

static int
qc_is_digit(const char *str)
{
    int index;
    for (index = 0; index < strlen(str); index++) {
        if (0 == isdigit(str[index]))
            return 0;
    }
    return 1;
}

int
qc_get_profile_int(const char *appName, const char *keyName, int defaultValue, const char *filePath)
{
    char defValue[32];
    char retString[32];
    int strRet;
    int retInt = -1;

    sprintf(defValue, "%d", defaultValue);
    strRet =
        qc_get_profile_string(appName, keyName, defValue, retString, sizeof(retString), filePath);
    if (-1 == strRet || 0 == strRet || 0 == qc_is_digit(retString))
        retInt = defaultValue;
    else
        retInt = atoi(retString);
    return retInt;
}

static const char *
qc_get_log_level(int level)
{
    switch (level) {
    case QC_LOG_DEBUG:
        return "[D]";
    case QC_LOG_INFO:
        return "[I]";
    case QC_LOG_WARN:
        return "[W]";
    case QC_LOG_ERROR:
        return "[E]";
    case QC_LOG_FATAL:
        return "[F]";
    case QC_LOG_ALL:
        return "[A]";
    default:
        return "";
    }
}

static void
qc_get_log_header(char *header, int size)
{
    char now_time[QC_NAME_MAX] = {0};
    struct tm *tmt = NULL;
    struct timeb tb;

    ftime(&tb);
    tmt = localtime(&tb.time);
    strftime(now_time, sizeof(now_time), "%y/%m/%d %H:%M:%S", tmt);
    QC_SNPRINTF(header, size, "%u.%s.%03u", qc_get_current_process_id(), now_time, tb.millitm);
}

static void
qc_get_log_name(const struct qc_fname fn, char *name, int size)
{
    QC_SNPRINTF(
        name, size, "%s.%s.%s-%d.%s", fn.process, fn.user, fn.create_time, fn.index, fn.ext);
}

static int
qc_get_fname_index(const char *path)
{
    char tmp[QC_PATH_MAX] = {0};
    char *p = NULL;

    if (!strstr(path, "-"))
        return 0;

    if (!strstr(path, g_data.name.user))
        return 0;

    strcpy(tmp, path);
    p = tmp + strlen(tmp);
    p -= strlen(g_data.name.ext);
    if (0 != strcmp(p, g_data.name.ext))
        return 0;

    do {
        p--;
        if (*p == '.')
            *p = '\0';
        if (*p == '-') {
            p++;
            break;
        }
    } while (1);

    return atoi(p);
}

static void
qc_get_log_path(const struct qc_data *fd, char *path, int size)
{
    char name[QC_NAME_MAX] = {0};
    qc_get_log_name(fd->name, name, sizeof(name));
    if (0 == strcmp(fd->dir, ""))
        QC_SNPRINTF(path, size, "%s", name);
    else
        QC_SNPRINTF(path, size, "%s%s%s", fd->dir, QC_PATH_SEPSTR, name);
}

static int
qc_get_file_size(const char *path, time_t *ctime)
{
    int ret;

#ifdef _WIN32
    struct _stat st;
    ret = _stat(path, &st);
#else
    struct stat st;
    ret = stat(path, &st);
#endif

    if (0 != ret)
        return -1;

    *ctime = st.st_ctime;
    return st.st_size;
}

static void
qc_check_directory(const char *dir)
{
    char tmp[QC_PATH_MAX] = {0};
    char tok[QC_PATH_MAX] = {0};
    char *p = NULL;

    if (-1 != QC_ACCESS(dir))
        return;

    strcpy(tmp, dir);
    p = strtok(tmp, QC_PATH_SEPSTR);
    while (p) {
        strcat(tok, p);
        strcat(tok, QC_PATH_SEPSTR);
        if (-1 == QC_ACCESS(dir))
            QC_MKDIR(tok);

        p = strtok(NULL, QC_PATH_SEPSTR);
    }
}

static void
qc_get_fname_time(char *time, int size)
{
    struct tm *tmt;
    struct timeb tb;

    ftime(&tb);
    tmt = localtime(&tb.time);
#ifdef USE_FNAME_WITH_TIME
    strftime(time, size, "%y%m%d%H%M%S", tmt);
#else
    strftime(time, size, "%y%m%d", tmt);
#endif
}

static void
qc_fname_update_time(struct qc_fname *fn)
{
    char time[QC_NAME_MAX] = {0};
    qc_get_fname_time(time, sizeof(time));
    strcpy(fn->create_time, time);
}

#ifdef _WIN32
static int
qc_travel_dir_tree(const char *dir, int (*filter)(const struct _finddata_t *fdate),
    int (*finfo)(const char *fpath, const struct stat *sb, int typeflag))
{
    struct stat st;
    struct _finddata_t fdate;
    char startp[QC_PATH_MAX];
    char subdirp[QC_PATH_MAX];
    long handle;
    int nextr;
    int infor;
    int result = 0;

    sprintf(startp, "%s\\*", dir);
    handle = (long)_findfirst(startp, &fdate);
    if (-1L == handle) {
        printf("_findfirst(%s)=-1L,{%d,%s}\n", startp, errno, strerror(errno));
        result = -1;
    } else {
        nextr = _findnext(handle, &fdate);
        while (0 == nextr) {
            if (1 == filter(&fdate)) {
                sprintf(subdirp, "%s\\%s", dir, fdate.name);
                stat(subdirp, &st);
                infor = finfo(subdirp, &st, fdate.attrib);
                if (0 != infor) {
                    printf("finfo(%s)=%d\n", subdirp, infor);
                    result = infor;
                    break;
                } else if (_A_SUBDIR == fdate.attrib) {
                    result = qc_travel_dir_tree(subdirp, filter, finfo);
                    if (0 != result)
                        break;
                }
            }
            nextr = _findnext(handle, &fdate);
        }
        _findclose(handle);
    }
    return result;
}

static int
qc_travel_filter_cb(const struct _finddata_t *fdate)
{
    if (_A_SUBDIR == fdate->attrib) {
        return 0;
    }

    if (NULL == strstr(fdate->name, g_data.name.ext) ||
        NULL == strstr(fdate->name, g_data.name.process) ||
        NULL == strstr(fdate->name, g_data.name.user)) {
        return 0;
    }

    return 1;
}

static int
qc_travel_finfo_cb(const char *path, const struct stat *sb, int typeflag)
{
    int findex = qc_get_fname_index(path);
    if (g_data.max_findex < findex)
        g_data.max_findex = findex;

    g_data.real_fnum++;

    if (0 == strcmp(g_data.earliest_path, "")) {
        strcpy(g_data.earliest_path, path);
        g_data.earliest_ctime = sb->st_ctime;
        return 0;
    }

    if (g_data.earliest_ctime > sb->st_ctime) {
        strcpy(g_data.earliest_path, path);
        g_data.earliest_ctime = sb->st_ctime;
    }

    return 0; // 1)==0 : continue;  2)!=0 : break
}
#else
static int
qc_travel_dir_tree(const char *dir, int (*filter)(const struct dirent *entry),
    int (*finfo)(const char *path, const struct stat *sb, const struct dirent *entry))
{
    struct stat st;
    struct dirent *entry;
    struct dirent **namelist;
    char path[QC_PATH_MAX];
    int index, total;
    int infor;
    int result = 0;

    total = scandir(dir, &namelist, filter, alphasort);
    if (0 > total) {
        printf("[error]scandir(%s)=%d,{%d:%s}\n", dir, total, errno, strerror(errno));
        return -1;
    } else {
        for (index = 0; index < total; index++) {
            entry = namelist[index];
            if (1 == filter(entry)) {
                sprintf(path, "%s/%s", dir, entry->d_name);
                stat(path, &st);
                infor = finfo(path, &st, entry);
                if (0 != infor) {
                    printf("finfo(%s)=%d\n", path, infor);
                    result = infor;
                    break;
                } else if (DT_DIR & entry->d_type) {
                    result = qc_travel_dir_tree(path, filter, finfo);
                    if (0 != result)
                        break;
                }
            }
            free(namelist[index]);
        }
        free(namelist);
    }
    return result;
}

static int
qc_travel_filter_cb(const struct dirent *entry)
{
    if (entry->d_type & DT_DIR) {
        return 0;
    }

    if (NULL == strstr(entry->d_name, g_data.name.ext) ||
        NULL == strstr(entry->d_name, g_data.name.process) ||
        NULL == strstr(entry->d_name, g_data.name.user)) {
        return 0;
    }

    return 1;
}

static int
qc_travel_finfo_cb(const char *path, const struct stat *sb, const struct dirent *entry)
{
    int findex = qc_get_fname_index(path);
    if (g_data.max_findex < findex)
        g_data.max_findex = findex;

    g_data.real_fnum++;

    if (0 == strcmp(g_data.earliest_path, "")) {
        strcpy(g_data.earliest_path, path);
        g_data.earliest_ctime = sb->st_ctime;
        return 0;
    }

    if (g_data.earliest_ctime > sb->st_ctime) {
        strcpy(g_data.earliest_path, path);
        g_data.earliest_ctime = sb->st_ctime;
    }

    return 0; // 1)==0 : continue;  2)!=0 : break
}
#endif

static void
qc_check_file_num()
{
    g_data.max_findex = 0;
    g_data.real_fnum = 0;
    strcpy(g_data.earliest_path, "");

    qc_travel_dir_tree(g_data.dir, qc_travel_filter_cb, qc_travel_finfo_cb);

    if (g_data.real_fnum > g_data.file_num) {
        remove(g_data.earliest_path);
    }
    g_data.name.index = g_data.max_findex + 1;
}

static void
qc_check_fsize_and_switch()
{
    char path[QC_NAME_MAX] = {0};
    time_t create_time;
    int fsize = 0;

    qc_get_log_path(&g_data, path, sizeof(path));
    fsize = qc_get_file_size(path, &create_time);
    if (0 > fsize)
        return;

    if (g_data.fsize_max > fsize) {
        return;
    }

    // check file num
    qc_check_file_num();

    // switch file
    fclose(g_data.fstream);
    qc_fname_update_time(&g_data.name);
    qc_get_log_path(&g_data, path, sizeof(path));
    g_data.fstream = fopen(path, "ab+");
}

static void
qc_print_file_header()
{
    unsigned int process_id = 0;
    char proc_path[QC_PATH_MAX] = {0};
    char work_dir[QC_PATH_MAX] = {0};
    char now_time[QC_NAME_MAX] = {0};
    int fsize = 0;
    time_t create_time;
    struct timeb tb;
    struct tm tmt;

    if (NULL == g_data.fstream)
        return;

    setbuf(g_data.fstream, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    qc_get_current_process_path(proc_path, sizeof(proc_path));
    qc_get_work_dir(work_dir, sizeof(work_dir));
    process_id = qc_get_current_process_id();
    fsize = qc_get_file_size(proc_path, &create_time);

    ftime(&tb);
    memcpy(&tmt, localtime(&tb.time), sizeof(struct tm));
    sprintf(now_time, "%04d/%02d/%02d %02d:%02d:%02d", tmt.tm_year + 1900, tmt.tm_mon + 1,
        tmt.tm_mday, tmt.tm_hour, tmt.tm_min, tmt.tm_sec);

    fprintf(g_data.fstream, "\r\n===================== LOG INFO BEGIN ===================\n");
    fprintf(g_data.fstream, "Process      Path : %s\n", proc_path);
    fprintf(g_data.fstream, "Work    Directory : %s\n", work_dir);
    fprintf(g_data.fstream, "File         Size : %u KB\n", fsize / 1024);
    fprintf(g_data.fstream, "Max          Size : %u KB\n", g_data.fsize_max / 1024);
    fprintf(g_data.fstream, "Max         Files : %u\n", g_data.file_num);
    fprintf(g_data.fstream, "Process        ID : %u\n", process_id);
    fprintf(g_data.fstream, "Current      Time : %s (sec:%ld, ms:%d, tz:%d, dst:%d)\n", now_time,
        (long)tb.time, tb.millitm, tb.timezone / 60, tb.dstflag);
    fprintf(g_data.fstream, "===================== LOG INFO END =====================\n\n");
    fflush(g_data.fstream);
}

static void
qc_fname_init(struct qc_fname *fn)
{
    char time[QC_NAME_MAX] = {0};

    memset(fn, 0, sizeof(struct qc_fname));
    qc_get_fname_time(time, sizeof(time));
    strcpy(fn->create_time, time);
    strcpy(fn->user, "default");
    strcpy(fn->ext, "log");
    fn->index = 0;
    qc_get_current_process_name(fn->process, sizeof(fn->process));
}

static void
qc_default_cfgpath(char *path, int size)
{
    char ppath[QC_PATH_MAX] = {0};
    char dir[QC_PATH_MAX] = {0};
    qc_get_current_process_path(ppath, sizeof(ppath));
    qc_path_onlydir(ppath, dir, sizeof(dir));
    QC_SNPRINTF(path, size, "%s%s%s", dir, QC_PATH_SEPSTR, USE_USER_CFGNAME);
}

static int
qc_default_init()
{
    char path[QC_PATH_MAX] = {0};
    char name[QC_NAME_MAX] = {0};
    int last_pos = 0;
    int rindex = 0;

    if (0 >= g_data.is_inited) {
        memset(&g_data, 0, sizeof(g_data));
        qc_lock_alloc(&g_data.lock);
        qc_default_cfgpath(g_data.cfgpath, sizeof(g_data.cfgpath));
        g_data.is_inited = 1;
    }

    if (-1 == QC_ACCESS(g_data.cfgpath))
        return 0;

    qc_get_profile_string("QCLOG", "dir", ".", g_data.dir, sizeof(g_data.dir), g_data.cfgpath);
    g_data.file_num = qc_get_profile_int("QCLOG", "filenum", 5, g_data.cfgpath);
    g_data.outflag = qc_get_profile_int("QCLOG", "outflag", 0, g_data.cfgpath);
    qc_fname_init(&g_data.name);
    qc_check_file_num();
    for (rindex = 0; rindex < g_data.real_fnum - g_data.file_num; rindex++) {
        qc_check_file_num();
    }
    g_data.name.index--;
    qc_get_log_name(g_data.name, name, sizeof(name));
    if (0 == strcmp(g_data.dir, "")) {
        strcpy(path, name);
    } else {
        last_pos = strlen(g_data.dir) - 1;
        if (QC_PATH_SEPCHAR == g_data.dir[last_pos])
            g_data.dir[last_pos] = '\0';

        qc_check_directory(g_data.dir);
        QC_SNPRINTF(path, sizeof(path), "%s%s%s", g_data.dir, QC_PATH_SEPSTR, name);
    }

    g_data.fsize_max = 50 * 1024 * 1024;
    g_data.fstream = fopen(path, "ab+");
    if (NULL == g_data.fstream)
        return -1;
    qc_print_file_header();
    return 0;
}

int
qc_init(const char *fdir, const char *fname, int fnum, int fsize_mb, int outflag)
{
    char path[QC_PATH_MAX] = {0};
    char dir[QC_NAME_MAX] = {0};
    char name[QC_NAME_MAX] = {0};
    int last_pos = 0;
    int rindex = 0;

    if (0 >= g_data.is_inited) {
        memset(&g_data, 0, sizeof(g_data));
        qc_lock_alloc(&g_data.lock);
        g_data.is_inited = 1;
    }

    strcpy(dir, fdir);
    last_pos = strlen(dir) - 1;
    if (QC_PATH_SEPCHAR == dir[last_pos])
        dir[last_pos] = '\0';

    memset(&g_data, 0, sizeof(g_data));
    QC_SNPRINTF(g_data.dir, QC_PATH_MAX, "%s", dir);
    qc_fname_init(&g_data.name);
    strcpy(g_data.name.user, fname);
    qc_check_file_num();
    for (rindex = 0; rindex < g_data.real_fnum - g_data.file_num; rindex++) {
        qc_check_file_num();
    }
    g_data.name.index--;
    qc_get_log_name(g_data.name, name, sizeof(name));
    g_data.file_num = fnum;
    g_data.fsize_max = fsize_mb * 1024 * 1024;
    g_data.outflag = outflag;

    qc_check_directory(fdir);

    QC_SNPRINTF(path, sizeof(path), "%s%s%s", fdir, QC_PATH_SEPSTR, name);
    g_data.fstream = fopen(path, "ab+");
    if (NULL == g_data.fstream)
        return -1;
    qc_print_file_header();
    return 0;
}

static int
qc_func_validchar(const char c)
{
    if (('a' <= c && 'z' >= c) || ('A' <= c && 'Z' >= c) || ('0' <= c && '9' >= c) || '_' == c ||
        ':' == c || '~' == c)
        return 0;
    return -1;
}

static void
qc_func_onlyname(const char *func, char *name, int size)
{
    int index = 0;
    char tmp[QC_NAME_MAX] = {0};
    sscanf(func, "%[^(]", tmp);

    for (index = strlen(tmp) - 1; index >= 0; index--) {
        if (0 > qc_func_validchar(tmp[index]))
            break;
    }
    index++;
    QC_SNPRINTF(name, size, "%s", tmp + index);
}

int
qc_log(int level, const char *file, int line, const char *func, const char *fmt, ...)
{
    char info[QC_PATH_MAX] = {0};
    char header[QC_NAME_MAX] = {0};
    char funcname[QC_NAME_MAX] = {0};
    va_list vlist;
    va_list vlist2;

    if (NULL == g_data.fstream) {
        if (0 > qc_default_init() || NULL == g_data.fstream)
            return -1;
    }

    qc_lock_enter(&g_data.lock);
    qc_get_log_header(header, sizeof(header));
    qc_func_onlyname(func, funcname, sizeof(funcname));

#ifdef USE_EXTEND
    QC_SNPRINTF(info, sizeof(info), "%s %s[%u|%s|%d|%s] ", header, qc_get_log_level(level),
        gc_get_current_thread_id(), file, line, funcname);
#else
    QC_SNPRINTF(info, sizeof(info), "%s %s[%u|%s] ", header, qc_get_log_level(level),
        gc_get_current_thread_id(), funcname);
#endif

    if (0 == g_data.outflag) {
        va_start(vlist, fmt);
        fprintf(g_data.fstream, "%s", info);
        vfprintf(g_data.fstream, fmt, vlist);
        va_end(vlist);
    } else if (1 == g_data.outflag) {
        va_start(vlist2, fmt);
        printf("%s\n", info);
        vprintf(fmt, vlist2);
        va_end(vlist2);
    } else if (2 == g_data.outflag) {
        va_start(vlist, fmt);
        va_copy(vlist2, vlist);
        fprintf(g_data.fstream, "%s", info);
        vfprintf(g_data.fstream, fmt, vlist);
        printf("%s\n", info);
        vprintf(fmt, vlist2);
        va_end(vlist);
        va_end(vlist2);
    }

    qc_check_fsize_and_switch();
    qc_lock_leave(&g_data.lock);
    return 0;
}

FILE *
qc_getfd()
{
    return g_data.fstream;
}
