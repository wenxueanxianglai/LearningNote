#include "frameio.h"

typedef CFrameIO::TFrame   TFrame;
typedef CFrameIO::TStream  TStream;

void CFrameIO::AddStream(TStream* stream)
{
    _streamMap.insert(std::make_pair(stream->stream_index, stream));
}

void CFrameIO::AddFrame(int stream_index, TFrame* frame)
{
    auto iter = _frameMap.find(stream_index);
    if (_frameMap.end() == iter) {
        std::list<TFrame*> frameList;
        frameList.push_back(frame);
        _frameMap.insert(std::make_pair(stream_index, frameList));
    }
    else {
        auto& frameList = iter->second;
        frameList.push_back(frame);
    }
}

const TStream* CFrameIO::GetStream(int stream_index) const
{
    auto iter = _streamMap.find(stream_index);
    if (_streamMap.end() == iter) {
        return nullptr;
    }

    return iter->second;
}

const TFrame* CFrameIO::GetFrame(int stream_index, int frame_index) const
{
    auto iter = _frameMap.find(stream_index);
    if (_frameMap.end() == iter) {
        return nullptr;
    }

    const TFrame* frame = nullptr;
    auto& frameList = iter->second;
    for (auto& f : frameList) {
        if (f->index == frame_index) {
            frame = f;
            break;
        }
    }
    return frame;
}

int CFrameIO::GetFrameNum(int stream_index) const
{
    auto iter = _frameMap.find(stream_index);
    if (_frameMap.end() == iter) {
        return 0;
    }

    auto& frameList = iter->second;
    return frameList.size();
}

int CFrameIO::GetVideoFrameNum(int stream_index) const
{
    auto iter = _frameMap.find(stream_index);
    if (_frameMap.end() == iter) {
        return 0;
    }

    int frameNum = 0;
    auto& frameList = iter->second;
    for (auto& f : frameList) {
        if (f->type == emIFrame
            || f->type == emPFrame
            || f->type == emBFrame) {
            frameNum++;
        }
    }
    return frameNum;
}

int CFrameIO::GetAudioFrameNum(int stream_index) const
{
    auto iter = _frameMap.find(stream_index);
    if (_frameMap.end() == iter) {
        return 0;
    }

    int frameNum = 0;
    auto& frameList = iter->second;
    for (auto& f : frameList) {
        if (f->type == emAudio) {
            frameNum++;
        }
    }
    return frameNum;
}

void CFrameIO::SaveVideoFrame(int stream_index)
{
    auto iter = _frameMap.find(stream_index);
    if (_frameMap.end() == iter) {
        return;
    }

    std::string path = _baseName + ".video";
    FILE *fd = fopen(path.data(), "wb+");
    if (NULL == fd)
        return;

    auto& frameList = iter->second;
    for (auto& f : frameList) {
        if (f->type == emIFrame
            || f->type == emPFrame
            || f->type == emBFrame) {
            fwrite(f->data, sizeof(uint8_t), f->size, fd);
        }
    }

    fclose(fd);
}

void CFrameIO::SaveAudioFrame(int stream_index)
{
    auto iter = _frameMap.find(stream_index);
    if (_frameMap.end() == iter) {
        return;
    }

    std::string path = _baseName + ".audio";
    FILE *fd = fopen(path.data(), "wb+");
    if (NULL == fd)
        return;

    auto& frameList = iter->second;
    for (auto& f : frameList) {
        if (f->type == emAudio) {
            fwrite(f->data, sizeof(uint8_t), f->size, fd);
        }
    }

    fclose(fd);
}

void CFrameFileIO::Read(const std::string& datPath, int streamIndex, int keyFrameSizeMin, int audioFrameSizeMax)
{
    FILE *fd = fopen(datPath.data(), "rb+");
    if (NULL == fd)
        return;

    int bufSize = keyFrameSizeMin * 3;
    uint8_t *buf = new uint8_t[bufSize];
    uint8_t *idle = buf;
    size_t idleSize = bufSize;
    uint8_t *curFrame = nullptr;
    uint8_t *nextFrame = nullptr;
    int frameIndex = 0;

    std::string txtPath = datPath + ".txt";
    std::ofstream ofs(txtPath);

    do {
        size_t readSize = fread(idle, sizeof(uint8_t), idleSize, fd);
        if (0 >= readSize) {
            break;
        }
    
        for (uint8_t *p = buf; p < buf + bufSize; p++) {
            if (!curFrame) {
                if (p[0] == 0x00 && p[1] == 0x00 && p[2] == 0x01 && p[3] == 0xBA) {
                    curFrame = p;
                }
            }
            else {
                if (p[0] == 0x00 && p[1] == 0x00 && p[2] == 0x01 && p[3] == 0xBA) {
                    nextFrame = p;
                }
            }

            if (curFrame && nextFrame) {
                int frameSize = nextFrame - curFrame;
                ofs << frameSize << "\n";

                TFrame* frame = new TFrame;
                frame->data = new uint8_t[frameSize];
                frame->size = frameSize;
                frame->index = frameIndex++;

                if (audioFrameSizeMax >= frameSize) {
                    frame->type = emAudio;
                }
                else {
                    if (keyFrameSizeMin <= frameSize)
                        frame->type = emIFrame;
                    else
                        frame->type = emPFrame;
                }

                memcpy(frame->data, curFrame, frameSize);
                AddFrame(streamIndex, frame);

                curFrame = nextFrame;
                nextFrame = nullptr;
            }
        }

        if (curFrame) {
            size_t delSize = curFrame - buf;
            size_t restSize = bufSize - delSize;
            memmove(buf, curFrame, restSize);
            idle = buf + restSize;
            idleSize = delSize;
            curFrame = nullptr;
        }

    } while (true);

    fclose(fd);
}



