#include "H264PSPacket2.h"
#include "PSStruct.h"


CH264PSPacket2::CH264PSPacket2(void)
	: m_nTIME_STAMP_INC(90000/25)
{
}

CH264PSPacket2::~CH264PSPacket2(void)
{
}

void CH264PSPacket2::SetFrameRate(uint32_t nFrameRate)
{
	if (1 <= nFrameRate && nFrameRate <= 60)
	{
		m_nTIME_STAMP_INC = 90000 / nFrameRate;
	}
}

uint32_t CH264PSPacket2::make_ps_packet_header(uint8_t *pHeader,uint32_t nHeaderLen,uint32_t nResolutionFlag,uint32_t nFrameIndex)
{
	if (NULL == pHeader || nHeaderLen < sizeof(PS_HEADER_tag))
	{
		return 0;
	}

	PS_HEADER_tag PSHeader;

	UINT64 ui64SCR = m_nTIME_STAMP_INC * nFrameIndex;
	PSHeader.setSystem_clock_reference_base(ui64SCR);
	PSHeader.setProgram_mux_rate(160001);

	memcpy(pHeader,&PSHeader,sizeof(PS_HEADER_tag));

	return sizeof(PS_HEADER_tag);
}

uint32_t CH264PSPacket2::make_pes_packet_header(uint8_t *pHeader,uint32_t nHeaderLen,uint32_t nDataLen,bool bSetPacketDataLen,uint32_t nFrameIndex, bool bAudioFrame/* = false*/)
{
	if(NULL == pHeader || nHeaderLen < sizeof(PES_HEADER_tag) + sizeof(PTS_tag))
	{
		return 0;
	}

	PES_HEADER_tag PESHeader;
	if (bAudioFrame)
	{
		PESHeader.stream_id = PS_AUDIO_FRAME_FLAG;
	}

	if(bSetPacketDataLen)
	{
		if(nDataLen >MAX_PES_DATA_SIZE)
			return 0;

		unsigned short sDataLen = nDataLen + 13;
		PESHeader.PES_packet_length[0] = sDataLen >> 8;
		PESHeader.PES_packet_length[1] = sDataLen & 0xFF;
	}

	PESHeader.original_or_copy = 0;
	PESHeader.copyright = 0;
	PESHeader.data_alignment_indicator = 1;
	PESHeader.PES_priority = 0;
	PESHeader.PES_scrambling_control = 0;

	PESHeader.PES_extension_flag = 0;
	PESHeader.PES_CRC_flag = 0;
	PESHeader.additional_copy_info_flag = 0;
	PESHeader.DSM_trick_mode_flag = 0;
	PESHeader.ES_rate_flag = 0;
	PESHeader.ESCR_flag = 0;
	PESHeader.PTS_DTS_flags = 0x03;

	PESHeader.PES_header_data_length = 0x0A;

	uint32_t nRetLen = 0;
	memcpy(pHeader,&PESHeader,sizeof(PES_HEADER_tag));
	nRetLen += sizeof(PES_HEADER_tag);

	PTS_tag PTS;
	UINT64 ui64SCR = m_nTIME_STAMP_INC * nFrameIndex;
	PTS.setPTS(ui64SCR);

	memcpy(pHeader + nRetLen,&PTS,sizeof(PTS_tag));
	nRetLen += sizeof(PTS_tag);

	PTS.fix_bit = 0x01;		
	memcpy(pHeader + nRetLen,&PTS,sizeof(PTS_tag));
	nRetLen += sizeof(PTS_tag);

	return nRetLen;
}

uint32_t CH264PSPacket2::PSPacket( uint8_t* pH264Frame, uint32_t nFrameSize, 
									 uint32_t nFrameIndex, PS_H264_FRAME_TYPE frameType, 
									 uint8_t* pPacketBuf, uint32_t nPacketBufSize)
{
	uint32_t nPacketSize = 0; //����һ��ps����С
	uint32_t nPos = 0;
	uint32_t nCopyDataSize = MAX_PES_DATA_SIZE;

	if(frameType == PS_H264_I_FRAME)
	{
		//ps_header
		nPacketSize += make_ps_packet_header(pPacketBuf, nPacketBufSize, 0, nFrameIndex);

		//Add for GB test
		gb28181_make_sys_header(pPacketBuf+nPacketSize);
		nPacketSize += SYS_HDR_LEN;

		//psm_header
		if(nPacketSize + sizeof(PSM_tag) > nPacketBufSize)
			return 0;

		PSM_tag psm;
		memcpy(pPacketBuf + nPacketSize, &psm, sizeof(PSM_tag));
		nPacketSize += sizeof(PSM_tag);

		while(nFrameSize>0)
		{
			if(nFrameSize < MAX_PES_DATA_SIZE)
			{
				nCopyDataSize = nFrameSize;
			}

			//pes_header
			nPacketSize += make_pes_packet_header(pPacketBuf + nPacketSize, nPacketBufSize - nPacketSize, nCopyDataSize, true, nFrameIndex);

			//h264
			if(nPacketSize + nCopyDataSize > nPacketBufSize)
				return 0;

			memcpy(pPacketBuf + nPacketSize, pH264Frame + nPos, nCopyDataSize);
			nPacketSize += nCopyDataSize;

			nFrameSize -= nCopyDataSize;
			nPos += nCopyDataSize;
		}
	}
	else
	{
		//ps_head
		nPacketSize += make_ps_packet_header(pPacketBuf, nPacketBufSize, 0, nFrameIndex);		

		while(nFrameSize > 0)
		{

			if(nFrameSize < MAX_PES_DATA_SIZE)
			{
				nCopyDataSize = nFrameSize;
			}

			//pes_head
			nPacketSize += make_pes_packet_header(pPacketBuf + nPacketSize, nPacketBufSize-nPacketSize, nCopyDataSize, true, nFrameIndex);

			//h264
			if(nPacketSize + nCopyDataSize > nPacketBufSize)
				return 0;

			memcpy(pPacketBuf + nPacketSize, pH264Frame + nPos, nCopyDataSize);
			nPacketSize += nCopyDataSize;

			nFrameSize -= nCopyDataSize;
			nPos += nCopyDataSize;
		}
	}

	return nPacketSize;
}

uint32_t CH264PSPacket2::PSAudio(uint8_t* pAudioFrame, uint32_t nFrameSize, uint32_t nFrameIndex, uint8_t* pPacketBuf, uint32_t nPacketBufSize, int audio_type /*= 0x90*/)
{
	//ps
	uint32_t nPacketSize = make_ps_packet_header(pPacketBuf, nPacketBufSize, 0, nFrameIndex);

	//sh
	nPacketSize += gb28181_make_sys_header(pPacketBuf+nPacketSize);

	//psm
	nPacketSize += gb28181_make_sys_map_header(pPacketBuf + nPacketSize, 0x1B, audio_type);

	//pes
	nPacketSize += make_pes_packet_header(pPacketBuf + nPacketSize, nPacketBufSize-nPacketSize, nFrameSize, true, nFrameIndex, true);

	if(nPacketSize + nFrameSize > nPacketBufSize)
		return 0;

	memcpy(pPacketBuf + nPacketSize, pAudioFrame, nFrameSize);
	nPacketSize += nFrameSize;

	return nPacketSize;
}

int CH264PSPacket2::gb28181_make_sys_header(uint8_t *pData)  
{  
	int nSize = sizeof(PSH_tag);

	PSH_tag sh;
	memcpy(pData, &sh, sizeof(PSH_tag));
	return sizeof(PSH_tag);
}

int CH264PSPacket2::gb28181_make_sys_map_header(uint8_t *pData, int video_type /*= 0x1B*/, int audio_type /*= 0x90*/)
{
	int nSize = sizeof(PSM_tag);

	PSM_tag sm;
	sm.video_stream_type = video_type;
	sm.audio_stream_type = audio_type;
	sm.crc32();
	memcpy(pData, &sm, sizeof(PSM_tag));	
	return sizeof(PSM_tag);
}