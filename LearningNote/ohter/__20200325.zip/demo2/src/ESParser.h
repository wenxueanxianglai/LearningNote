#pragma once
#include "ESAnalyzer.h"
#include "IH264Parser.h"

class CESParser :
	public IH264Parser
{
public:
	CESParser(uint8_t* pPSBuffer, uint32_t nPSBufferSize, uint32_t nFrameRate);
	~CESParser(void);

	NAKED_PES_INFO GetAFrame();		

	void Clear();

private:
	CESAnalyzer		m_esAnalyzer;

	int			m_nDefaultFrameRate;

	ESStatus      m_status;				//��ǰ״̬
	uint32_t		  m_nESIndicator;       //ESָ��

	int		m_iESStartPos;

	uint32_t	m_nLastFrameTick;

	uint32_t	m_nFrameSpan;
};
