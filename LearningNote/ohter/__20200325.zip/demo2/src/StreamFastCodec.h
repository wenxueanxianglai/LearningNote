﻿#pragma once

#include <array>
#include <iostream>
#include <list>
#include "StreamToESFrameParser.h"
#include "H264PSPacket2.h"

typedef ES_FRAME_INFO  FRAME_INFO_T;

class CStreamFastCodec
{
public:
    CStreamFastCodec(uint32_t cacheNumMax = 5);
    ~CStreamFastCodec();

    bool PushOneFrame(const FRAME_INFO_T& frame);
    bool GetOneEsFrame(ES_FRAME_INFO& esFrame); //need delete[] esFrame.pFrameData when success
    bool GetOnePsFrame(ES_FRAME_INFO& esFrame, uint8_t*& psFrameData, uint32_t& psFrameSize);

private:
    FRAME_INFO_T* CopyFrame(const FRAME_INFO_T* frame);
    void FreeFrame(const FRAME_INFO_T* frame);
    void PushQueue(const FRAME_INFO_T& frame);
    void ClearQueue();

private:
    uint32_t _pushSizeCnt;
    uint32_t _getSizeCnt;
    uint32_t _cacheNumMax;
    std::list<ES_FRAME_INFO*> _cacheList;
    CStreamToESFrameParser _toEsFrame;
    CH264PSPacket2 _psPacket;
};

