#include "PSAnalyzer.h"

CPSAnalyzer::CPSAnalyzer(void)
{
}

CPSAnalyzer::~CPSAnalyzer(void)
{
}


uint64_t CPSAnalyzer::ff_parse_pes_pts(const unsigned char* buf)
{
    return (uint64_t)(*buf & 0x0e) << 29 |
		(AV_RB16(buf+1) >> 1) << 15 |
		AV_RB16(buf+3) >> 1;
}

uint64_t CPSAnalyzer::get_pts(optional_pes_header* option)
{
	if(option->PTS_DTS_flags != 2 && option->PTS_DTS_flags != 3 && option->PTS_DTS_flags != 0)
	{
		return 0;
	}
	if((option->PTS_DTS_flags & 2) == 2)
	{
		unsigned char* pts = (unsigned char*)option + sizeof(optional_pes_header);
		return ff_parse_pes_pts(pts);
	}
	return 0;
}

uint64_t CPSAnalyzer::get_dts(optional_pes_header* option)
{
	if(option->PTS_DTS_flags != 2 && option->PTS_DTS_flags != 3 && option->PTS_DTS_flags != 0)
	{
		return 0;
	}
	if((option->PTS_DTS_flags & 3) == 3)
	{
		unsigned char* dts = (unsigned char*)option + sizeof(optional_pes_header) + 5;
		return ff_parse_pes_pts(dts);
	}
	return 0;
}

bool CPSAnalyzer::is_ps_header(ps_header_t* ps)
{
	if(ps->pack_start_code[0] == 0 && ps->pack_start_code[1] == 0 && ps->pack_start_code[2] == 1 && ps->pack_start_code[3] == 0xBA)
		return true;
	return false;
}

bool CPSAnalyzer::is_sh_header(sh_header_t* sh)
{
	if(sh->system_header_start_code[0] == 0 && sh->system_header_start_code[1] == 0 && sh->system_header_start_code[2] == 1 && sh->system_header_start_code[3] == 0xBB)
		return true;
	return false;
}

bool CPSAnalyzer::is_psm_header(psm_header_t* psm)
{
	if(psm->promgram_stream_map_start_code[0] == 0 && psm->promgram_stream_map_start_code[1] == 0 && psm->promgram_stream_map_start_code[2] == 1 && psm->promgram_stream_map_start_code[3] == 0xBC)
		return true;
	return false;
}

bool CPSAnalyzer::is_pes_video_header(pes_header_t* pes)
{
	if(pes->pes_start_code_prefix[0]==0 && pes->pes_start_code_prefix[1] == 0 && pes->pes_start_code_prefix[2] == 1 && is_video_stream_id(pes->stream_id)) //pes->stream_id == 0xE0
		return true;
	return false;
}

bool CPSAnalyzer::is_pes_audio_header(pes_header_t* pes)
{
	if(pes->pes_start_code_prefix[0]==0 && pes->pes_start_code_prefix[1] == 0 && pes->pes_start_code_prefix[2] == 1 && is_audio_stream_id(pes->stream_id))
		return true;
	return false;
}

bool CPSAnalyzer::is_pes_header(pes_header_t* pes)
{
	if(pes->pes_start_code_prefix[0]==0 && pes->pes_start_code_prefix[1] == 0 && pes->pes_start_code_prefix[2] == 1)
	{
		if(is_audio_stream_id(pes->stream_id) || is_video_stream_id(pes->stream_id) ) //pes->stream_id == 0xE0
		{		
			return true;
		}
	}
	return false;
}

PSStatus CPSAnalyzer::pes_type(pes_header_t* pes)
{
	if(pes->pes_start_code_prefix[0]==0 && pes->pes_start_code_prefix[1] == 0 && pes->pes_start_code_prefix[2] == 1)
	{
		if(is_audio_stream_id(pes->stream_id)) //pes->stream_id == 0xC0
		{
			return ps_pes_audio;
		}
		else if(is_video_stream_id(pes->stream_id))	//pes->stream_id == 0xE0
		{
			return ps_pes_video;
		}
	}
	return ps_padding;
}

bool CPSAnalyzer::is_video_stream_id(uint8_t stream_id) 
{
	//if ((stream_id&0xE0) == 0xE0) 2017-08-22 Modify
	if (stream_id == 0xE0)
		return true;

	return false;
}

bool CPSAnalyzer::is_audio_stream_id(uint8_t stream_id) //(C0~DFΪ��ƵID)
{
	//if (0xC0 <= stream_id && stream_id <= 0xDF)

	if (0xC0 == stream_id)  //2017-08-22 Modify
	{
		return true;
	}

	return false;
}

PS_PAYLOAD_TYPE CPSAnalyzer::GetPSPayloadType(uint8_t* pBuf, uint32_t nBufSize)
{
	PS_PAYLOAD_TYPE payloadType = ps_payload_padding;
	int nal_unit_type = 0;
	if (pBuf[0] == 0x00 && pBuf[1] == 0x00 && pBuf[2] == 0x00 && pBuf[3] == 0x01)
	{
		nal_unit_type = pBuf[4] & 0x1f;

	} 
	else if (pBuf[0] == 0x00 && pBuf[1] == 0x00 && pBuf[2] == 0x01)
	{
		nal_unit_type = pBuf[3] & 0x1f;
	}

	switch (nal_unit_type)
	{
	case 1:
		payloadType = ps_payload_slice_non_idr;
		break;

	case 5:
		payloadType = ps_payload_slice_idr;
		break;

	case 7:
		payloadType = ps_payload_sps;
		break;

	case 8:
		payloadType = ps_payload_pps;
		break;

	default:
		break;
	}	

	return payloadType;
}
