#pragma once
#include "IH264Parser.h"
#include "PSAnalyzer.h"
#include "PSFrameParser.h"



class CPSParser :
	public IH264Parser
{
public:
	CPSParser(uint8_t* pPSBuffer, uint32_t nPSBufferSize);
	~CPSParser(void);

#ifdef SUPPORT_DIRECT_GET_AFRAME
	NAKED_PES_INFO GetAFrame();		//2014-07-02 Add һ֡���ݿ�����һ��PS�Ͷ��PES��װ
#else
	NAKED_PES_INFO GetNakedPayload();
#endif

	bool GetPSPacket(PS_PACKET_INFO& psPacket);	//2014-03-17 Add

	void Clear();
    
	bool IsEmpty() { return m_nPSWritePos==0; }

	bool IsH264ParamSet(uint8_t* pBuf, uint32_t nBufSize);	//2015-04-02 Add

	bool FlushData(uint8_t* & pBuf, uint32_t& nDataLength);

private:
#ifdef SUPPORT_DIRECT_GET_AFRAME
	PES_INFO GetFrame_pes_payload();

	void GetNextDts();	//2014-07-12 Add
#else
	PES_INFO pes_payload();
#endif

	//bool IsReadEnd() { return m_nPESIndicator >= m_nPSWritePos; }	//2016-03-02 Add

	bool IsReadEnd() { return m_nPESIndicator >= m_nPSWritePos || m_nNextPESIndicator >= m_nPSWritePos; }	//2016-03-02 Add

	PS_PAYLOAD_TYPE GetPSPayloadType(uint8_t* pBuf, uint32_t nBufSize);	//2017-01-22 Add

	virtual int GetVideoCodec() { return m_frameParser.GetVideoCodec(); }

private:
	CPSAnalyzer		m_psAnalyzer;

	CPSFrameParser	m_frameParser;		//2017-10-10 Add

	PSStatus      m_status;                     //��ǰ״̬

	uint32_t		  m_nPESIndicator;              //PESָ��

	uint8_t*         m_pPESBuffer;					//PES������
	uint32_t		  m_nPESLength;                 //PES���ݳ���

	PS_PAYLOAD_TYPE m_payloadType;

	ps_header_t*  m_ps;                         //PSͷ
	sh_header_t*  m_sh;                         //ϵͳͷ
	psm_header_t* m_psm;                        //��Ŀ��ͷ
	pes_header_t* m_pes;                        //PESͷ

#ifdef SUPPORT_DIRECT_GET_AFRAME
	uint32_t			m_nPSStartPos;				//PS֡����ʼλ�� 

	PSStatus      m_nextStatus;                     //��һ֡ǰ״̬
	uint32_t		  m_nNextPESIndicator;              //��һ֡PESָ��
	uint8_t		m_nextStreamID;

	uint64_t        m_nextdts;					//2014-07-11 Add
	bool            m_bFrameHeader;

#endif

	//H264	PES_packet_length ���ܳ���16λ, ��������PES_packet_length��m_nH264PES_packet_lengthΪ׼
	uint32_t		  m_nH264PES_packet_length;	
	uint32_t		  m_nH264PS_packet_length;                 //PS���ݳ���

	bool		m_bVideoFrame;

	//bool		  m_bLastValid;				//2014-09-29 Add
	//uint32_t		  m_nMinParseLength;

};
