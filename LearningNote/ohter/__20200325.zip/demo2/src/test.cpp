﻿#include "StreamFastCodec.h"
#include "frameio.h"
#include "quicklog.h"
#include <iostream>
#include <queue>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

int dat();

int main()
{
    QCLOG(QC_LOG_INFO, "GO!\n");

    dat();

    QCLOG(QC_LOG_INFO, "OVER!");
    return 0;
}

int dat()
{
#define BASE_NAME              "hik-OldRecStream"
#define KEYFRAME_SIZE_MIN      7000
#define AUDIOFRAME_SIZE_MAX    200
#define DAT_NAME               BASE_NAME".dat"

    int streamIndex = 0;

    CFrameFileIO srcIO(BASE_NAME);
    srcIO.Read(DAT_NAME, streamIndex, KEYFRAME_SIZE_MIN, AUDIOFRAME_SIZE_MAX);
    QCLOG(QC_LOG_INFO, "srcIO GetFrameNum(%d) GetVideoFrameNum(%d) GetAudioFrameNum(%d)\n",
        srcIO.GetFrameNum(streamIndex),
        srcIO.GetVideoFrameNum(streamIndex),
        srcIO.GetAudioFrameNum(streamIndex));

    std::stringstream esName, psName;
    esName << BASE_NAME << "-ES";
    psName << BASE_NAME << "-PS";
    CFrameFileIO esIO(esName.str()), psIO(psName.str());

    for (int n = 0; n < 1; n++) {
        CStreamFastCodec fastCodec;
        for (int i = 0; i < srcIO.GetFrameNum(streamIndex); i++) {
            const CFrameIO::TFrame* srcFrame = srcIO.GetFrame(streamIndex, i);

            FRAME_INFO_T pushFrame;
            pushFrame.pFrameData = srcFrame->data;
            pushFrame.lFrameSize = srcFrame->size;
            pushFrame.bIFrame = (srcFrame->type == CFrameIO::emIFrame) ? true : false;
            pushFrame.bAudio = (srcFrame->type == CFrameIO::emAudio) ? true : false;
            if (fastCodec.PushOneFrame(pushFrame)) {
                ES_FRAME_INFO esFrame;
                uint8_t* psFrameData = nullptr;
                uint32_t psFrameSize = 0;
                while (fastCodec.GetOnePsFrame(esFrame, psFrameData, psFrameSize)) {
                    QCLOG(QC_LOG_INFO, "GetOnePsFrame psFrameSize(%u) esFrameInfo.{pFrameData(%#p) lFrameSize(%d) nFrameTick(%d) bIFrame(%d) bAudio(%d)}\n",
                        psFrameSize, esFrame.pFrameData, esFrame.lFrameSize, esFrame.nFrameTick, esFrame.bIFrame, esFrame.bAudio);

#if 1
                    CFrameIO::TFrame *esF = new CFrameIO::TFrame();
                    esF->index = srcFrame->index;
                    esF->data = esFrame.pFrameData;
                    esF->size = esFrame.lFrameSize;
                    if (esFrame.bAudio) {
                        esF->type = CFrameIO::emAudio;
                    }
                    else {
                        if (esFrame.bIFrame)
                            esF->type = CFrameIO::emIFrame;
                        else
                            esF->type = CFrameIO::emPFrame;
                    }
                    esIO.AddFrame(streamIndex, esF);

/*
                    CFrameIO::TFrame *psF = new CFrameIO::TFrame();
                    psF->index = esF->index;
                    psF->data = psFrameData;
                    psF->size = psFrameSize;
                    psF->type = esF->type;
                    psIO.AddFrame(streamIndex, psF);*/
#endif

                    //delete[] esFrame.pFrameData;
                    //delete[] psFrameData;
                }
            }
        }
    }

    if (0 < esIO.GetVideoFrameNum(streamIndex)) {
        esIO.SaveVideoFrame(streamIndex);
    }

    if (0 < esIO.GetAudioFrameNum(streamIndex)) {
        esIO.SaveAudioFrame(streamIndex);
    }

    return 0;
}


