#include "StreamToESFrameParser.h"

#include "ESParser.h"
#include "PSParser.h"

#include "H264Parse.h"

CStreamToESFrameParser::CStreamToESFrameParser()
	: m_buf(NULL)
	, m_nDataLength(0)
	, m_pStreamParser(NULL)
	, m_bESStream(false)
	, m_bParserCreated(false)
	, m_bFirstFrameParsed(false)
	, m_videoCodec(PS_unknown)
	, m_nFirstFrameTick(0)
	, m_nDefaultFrameRate(25)
{
	Activate();
}


CStreamToESFrameParser::~CStreamToESFrameParser()
{
	SAFE_DEL(m_pStreamParser);
	SAFE_DEL(m_buf);
}

void CStreamToESFrameParser::Activate()
{
	Deactivate();

	if (m_buf == NULL)
	{
		m_buf = new uint8_t[PARSE_BUF_SIZE];
	}
}

void CStreamToESFrameParser::SetStreamType(bool bESStream, PS_VIDEO_CODEC videoCodec)
{
	m_videoCodec = videoCodec;

	CreateParser(bESStream);
}

void CStreamToESFrameParser::Deactivate()	//����
{
	Clear();

	m_nDataLength = 0;
	m_bParserCreated = false;
	m_bFirstFrameParsed = false;

	m_videoCodec = PS_unknown;
	m_nFirstFrameTick = 0;

}

bool CStreamToESFrameParser::PushStream(uint8_t* pFrameData, uint32_t lFrameSize)
{
	if (!m_bParserCreated)
	{
		return InitParser(pFrameData, lFrameSize);
	}

	if (m_pStreamParser->GetBufFreeSize() < lFrameSize)
	{
		m_pStreamParser->Clear();
	}

	m_pStreamParser->PSWrite(pFrameData, lFrameSize);

	return true;
}

bool CStreamToESFrameParser::GetFrame(ES_FRAME_INFO& frame)
{
	if (!m_bParserCreated)
		return false;

	NAKED_PES_INFO nakedPes = m_pStreamParser->GetAFrame();
	if (nakedPes.bValid)
	{
		frame.pFrameData = new uint8_t[nakedPes.nESLength];
		if (frame.pFrameData == NULL)
			return false;

		if (!m_bFirstFrameParsed && nakedPes.byType == 0xE0)
		{
			m_nFirstFrameTick = nakedPes.pts / 90;
			m_bFirstFrameParsed = true;
		}

		memcpy(frame.pFrameData, nakedPes.pESBuffer, nakedPes.nESLength);
		frame.lFrameSize = nakedPes.nESLength;
		frame.nFrameTick = nakedPes.pts / 90 - m_nFirstFrameTick;

		frame.bIFrame = nakedPes.bIFrame;

		frame.bAudio = false;
		if (nakedPes.byType != 0xE0)
		{
			frame.bAudio = true;
		}
	}

	return nakedPes.bValid;
}

/*
bool CStreamToESFrameParser::GetMediaFrame(UMT_MEDIA_FRAME& mediaFrame)
{
	if (!m_bParserCreated)
		return false;

	NAKED_PES_INFO nakedPes = m_pStreamParser->GetAFrame();
	if (nakedPes.bValid)
	{
		mediaFrame.buf = std::shared_ptr<uint8_t>(new uint8_t[nakedPes.nESLength], std::default_delete<uint8_t[]>());
		if (mediaFrame.buf == nullptr)
			return false;

		memcpy(mediaFrame.buf.get(), nakedPes.pESBuffer, nakedPes.nESLength);
		mediaFrame.len = nakedPes.nESLength;
		mediaFrame.nTimeStamp = (uint32_t)nakedPes.pts;

		if (!m_bFirstFrameParsed && nakedPes.byType == 0xE0)
		{
			m_nFirstFrameTick = nakedPes.pts / 90;
			m_bFirstFrameParsed = true;
		}

		uint32_t nCurTick = nakedPes.pts / 90;
		if (nCurTick < m_nFirstFrameTick && (m_nFirstFrameTick- nCurTick) > 3600*1000) //����ĳЩ�豸Ϊ32Ϊpts���룬ʱ��������ת����
		{
			mediaFrame.nFrameTick = nCurTick+(0xFFFFFFFF)/90 - m_nFirstFrameTick;
		}
		else
		{
			mediaFrame.nFrameTick = nCurTick - m_nFirstFrameTick;
		}

		mediaFrame.bIFrame = nakedPes.bIFrame;

		mediaFrame.bAudio = false;
		if (nakedPes.byType != 0xE0)
		{
			mediaFrame.bAudio = true;
		}
	}

	return nakedPes.bValid;
}*/

uint32_t CStreamToESFrameParser::GetBufFreeSize()
{
    if (m_bParserCreated)
    {
        return m_pStreamParser->GetBufFreeSize();
    }

    return false;
}

bool CStreamToESFrameParser::HasMultipleFrame()
{
	if (m_bParserCreated)
	{
		return m_pStreamParser->HasMultipleFrame();
	}

	return false;
}

bool CStreamToESFrameParser::IsParseCodecEnd()
{
	if (m_videoCodec != PS_unknown || m_nDataLength >= (1 << 20))
	{
		return true;
	}

	return false;
}

bool CStreamToESFrameParser::GetInputData(uint8_t* & pBuf, uint32_t& lBufSize)
{
	if (m_nDataLength > 0)
	{
		pBuf = m_buf;
		lBufSize = m_nDataLength;

		return true;
	}

	return false;
}

void CStreamToESFrameParser::Clear()
{
	m_videoCodec = PS_unknown;

	if (m_pStreamParser != NULL)
	{
		m_pStreamParser->Clear();
	}
}

bool CStreamToESFrameParser::InitParser(uint8_t* pBuf, uint32_t nSize)
{
	if (pBuf == NULL || nSize < 4)
		return false;

	if (m_nDataLength + nSize > PARSE_BUF_SIZE)
	{
		m_nDataLength = 0;
	}

	if (m_nDataLength + nSize < PARSE_BUF_SIZE)
	{
		memcpy(m_buf + m_nDataLength, pBuf, nSize);
		m_nDataLength += nSize;
	}	

	if (m_videoCodec == PS_unknown)
	{
		CPSFrameParser parser;
		if (parser.CheckStreamType(m_buf, m_nDataLength))
		{
			m_videoCodec = parser.GetVideoCodec();
		/*	if (!IsStreamSupportGPUDecode())
			{
				return false;
			}*/
		}
		else
		{
			return false;
		}
	}

	bool bESStream = true;

	bool bFirstPosFindES = false;
	bool bFindStreamType = false;
	if (m_buf[0] == 0 && m_buf[1] == 0 && m_buf[2] == 1 && ((0xBA <= m_buf[3] && m_buf[3] <= 0xBD) || m_buf[3] == 0xE0 || m_buf[3] == 0xC0))
	{
		bESStream = false;
		bFindStreamType = true;
	}
	else
	{
		for (int i = 0; i < m_nDataLength; i++)
		{
			if (m_buf[i] == 0x00 && m_buf[i + 1] == 0x00 && m_buf[i + 2] == 0x01)	//nal_unit_type: 7-���в�����
			{
				int nal_unit_type = m_buf[i + 3] & 0x1f;
				if (1 <= nal_unit_type && nal_unit_type <= 12)
				{
					if (i > 4)
					{
						for (int k = i - 4; k > i - 100 && k > 0; k--)
						{
							if (m_buf[k] == 0 && m_buf[k + 1] == 0 && m_buf[k + 2] == 1 && ((0xBA <= m_buf[k + 3] && m_buf[k + 3] <= 0xBD) || m_buf[k + 3] == 0xE0 || m_buf[k + 3] == 0xC0))
							{
								//OutputDebug("[ezPlayCtrl] is PS Stream");

								bESStream = false;
								bFindStreamType = true;
								break;
							}
						}
					}

					if (!bFindStreamType)
					{
						bESStream = true;
						bFindStreamType = true;
					}

					break;
				}
			}
		}
	}

	return CreateParser(bESStream);
}

bool CStreamToESFrameParser::CreateParser(bool bESStream)
{
	if (m_bESStream != bESStream)
	{
		SAFE_DEL(m_pStreamParser);

		m_bESStream = bESStream;
	}

	if (m_pStreamParser == NULL)
	{
		if (m_bESStream)
		{
			uint32_t nFrameRate = m_nDefaultFrameRate;
			ParseFrameRate(nFrameRate);

			m_pStreamParser = new CESParser(m_buf, PARSE_BUF_SIZE, nFrameRate);
		}
		else
		{
			m_pStreamParser = new CPSParser(m_buf, PARSE_BUF_SIZE);
		}
	}

	if (m_pStreamParser != NULL)
	{
		m_pStreamParser->InitSizeData(m_nDataLength);
		m_bParserCreated = true;
	}

	return m_bParserCreated;
}

bool CStreamToESFrameParser::ParseFrameRate(uint32_t& nFrameRate)
{
	if (m_videoCodec == PS_h264)
	{
		int nalType = 0;
		int lastNalType = 0;
		int iLastNalStart = 0;
		int iCurNalStart = 0;

		for (int i = 0; i < m_nDataLength; i++)
		{
			nalType = 0;
			if (m_buf[i] == 0x00 && m_buf[i + 1] == 0x00 && m_buf[i + 2] == 0x01)
			{
				nalType = m_buf[i + 3] & 0x1f;
				iCurNalStart = i + 3;
			}
			else if (m_buf[i] == 0x00 && m_buf[i + 1] == 0x00 && m_buf[i + 2] == 0x00 && m_buf[i + 3] == 0x01)
			{
				nalType = m_buf[i + 4] & 0x1f;
				iCurNalStart = i + 4;
			}

			switch (nalType)
			{
			case h264_nal_slice_idr:
			case h264_nal_slice_non_idr:
			{
				if (lastNalType == h264_nal_sps)
				{
					return ParseSpsNal(m_buf + iLastNalStart, i - iLastNalStart, nFrameRate);
				}

				return true;
			}
			break;

			case h264_nal_sps:
			case h264_nal_pps:
			{
				if (lastNalType == h264_nal_sps)
				{
					return ParseSpsNal(m_buf + iLastNalStart, i - iLastNalStart, nFrameRate);
				}

				lastNalType = nalType;
				iLastNalStart = iCurNalStart;

				i = iCurNalStart;
			}
			break;

			case h264_nal_sei:
			{
				if (lastNalType == h264_nal_sps)
				{
					return ParseSpsNal(m_buf + iLastNalStart, i - iLastNalStart, nFrameRate);
				}

				lastNalType = h264_nal_sei;

				i = iCurNalStart;
			}
			break;
			}
		}

	}

	return false;
}

bool CStreamToESFrameParser::ParseSpsNal(uint8_t* pSpsPos, uint32_t nSpsSize, uint32_t& nFrameRate)
{
	if (m_videoCodec == PS_h264)
	{
		sps_info_t sps;
		if (h264_parse_sps(pSpsPos, nSpsSize, &sps))
		{
			if (1 <= sps.fps && sps.fps <= 60)
			{
				nFrameRate = sps.fps;
				return true;
			}	
		}		
	}
	
	return false;
}
