#pragma once

#include "PSParser.h"

struct ES_FRAME_INFO
{
	uint8_t*	pFrameData;
	uint32_t	lFrameSize;

	uint32_t	nFrameTick;
	bool	bIFrame;
	bool	bAudio;

	ES_FRAME_INFO()
	{
		memset((void*)this, 0, sizeof(ES_FRAME_INFO));
	}
};

const uint32_t PARSE_BUF_SIZE = 3 << 19; //1.5MB


class CStreamToESFrameParser
{
public:
	CStreamToESFrameParser();
	~CStreamToESFrameParser();
	
	void SetDefaultFrameRate(uint32_t nDefaultFrameRate) { m_nDefaultFrameRate = nDefaultFrameRate; }

	void Activate();	//����  
	void Deactivate();	//����

	void SetStreamType(bool bESStream, PS_VIDEO_CODEC videoCodec);

	bool PushStream(uint8_t* pFrameData, uint32_t lFrameSize);
	bool GetFrame(ES_FRAME_INFO& frame);
	//bool GetMediaFrame(UMT_MEDIA_FRAME& mediaFrame);

    uint32_t GetBufFreeSize();
	bool HasMultipleFrame();

	bool IsParseCodecEnd();

	bool GetInputData(uint8_t* & pBuf, uint32_t& lBufSize); //��֧�ֵĽ������ͣ���UMTPlayCtrl������

	PS_VIDEO_CODEC GetVideoCodec() { return m_videoCodec; }

	void Clear();

private:
	bool InitParser(uint8_t* pBuf, uint32_t nSize);
	bool CreateParser(bool bESStream);

	bool ParseFrameRate(uint32_t& nFrameRate);
	bool ParseSpsNal(uint8_t* pSpsPos, uint32_t nSpsSize, uint32_t& nFrameRate);

private:
	bool			m_bESStream;
	bool			m_bParserCreated;
	bool			m_bFirstFrameParsed;

	uint32_t		m_nDefaultFrameRate;

	PS_VIDEO_CODEC	m_videoCodec;

	uint8_t*			m_buf;
	int				m_nDataLength;
	IH264Parser*	m_pStreamParser;

	uint32_t			m_nFirstFrameTick;

};

