#pragma once
#include "Pack_Header_Def.h"

const uint32_t MAX_PES_DATA_SIZE = 0xFF00;	//pes����װ����������С������ֵ��ְ���װ

enum PS_H264_FRAME_TYPE
{
	PS_H264_UNKNOWN_TYPE = 0,
	PS_H264_I_FRAME,
	PS_H264_P_FRAME,
};

class CH264PSPacket2
{
public:
	CH264PSPacket2(void);
	~CH264PSPacket2(void);

	void SetFrameRate(uint32_t nFrameRate);

	uint32_t PSPacket(uint8_t* pH264Frame, uint32_t nFrameSize, uint32_t nFrameIndex, PS_H264_FRAME_TYPE frameType, uint8_t* pPSBuffer, uint32_t nPSBufferSize);

	uint32_t PSAudio(uint8_t* pAudioFrame, uint32_t nFrameSize, uint32_t nFrameIndex, uint8_t* pPSBuffer, uint32_t nPSBufferSize, int audio_type = 0x90);	//2017-11-01 Add

private:
	uint32_t make_ps_packet_header(uint8_t *pHeader,uint32_t iHeaderLen,uint32_t iResolutionFlag,uint32_t iFrameIndex);
	uint32_t make_pes_packet_header(uint8_t *pHeader,uint32_t iHeaderLen,uint32_t iDataLen,bool bSetPacketDataLen,uint32_t iFrameIndex, bool bAudioFrame = false);

	int gb28181_make_sys_header(uint8_t *pData); 
	int gb28181_make_sys_map_header(uint8_t *pData, int video_type = 0x1B, int audio_type = 0x90); 

private:
	uint32_t	m_nTIME_STAMP_INC;

};