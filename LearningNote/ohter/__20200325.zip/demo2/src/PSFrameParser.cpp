#include "PSFrameParser.h"
#include <math.h> 

const int STREAM_SCAN_LENGTH = 800;	//��ͬ��Ӧ�ò�ͬ��scan����


CPSFrameParser::CPSFrameParser(void)
{
	Reset();
}

CPSFrameParser::~CPSFrameParser(void)
{
}

void CPSFrameParser::Reset()
{
	m_videoCodec = PS_unknown;

	m_bFindH264SPS = false;
	m_bFindH264PPS = false;

	m_bFindH265SPS = false;
	m_bFindH265PPS = false;
	m_bFindH265VPS = false;

	m_bFindSvacSPS = false;
	m_bFindSvacPPS = false;

	m_bFrameParseOk = false;
}

bool CPSFrameParser::IsIFrame(uint8_t* pBuf, uint32_t nBufSize)
{
	if (m_videoCodec == PS_unknown)
	{
		CheckStreamType(pBuf, nBufSize);
	}

	switch (m_videoCodec)
	{
	case PS_h264:
		return IsH264IFrame(pBuf, nBufSize);

	case PS_h265:
		return IsH265IFrame(pBuf, nBufSize);

	case PS_mpeg4:
		return IsMPEG4IFrame(pBuf, nBufSize);

	case PS_svac:
		return IsSvacIFrame(pBuf, nBufSize);
	}	

	return false;
}

bool CPSFrameParser::IsIFrameEx(uint8_t* pBuf, uint32_t nBufSize, bool& bFrameParseOk)
{
	m_bFrameParseOk = false;
	bool bRet = IsIFrame(pBuf, nBufSize);

	bFrameParseOk = m_bFrameParseOk;
	return bRet;
}


bool CPSFrameParser::IsH264IFrame(uint8_t* pBuf, uint32_t nBufSize)
{
	int iNalTypePos = -1;

	bool bFindSPS = false;
	bool bFindPPS = false;

	//00 00 01��ͷ
	for (int i = 0; i < STREAM_SCAN_LENGTH && i < nBufSize-4; i++) //00 00 01 Ҳ��PS��ͷ
	{
		iNalTypePos = -1;
		if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x01)
		{
			iNalTypePos = i+3;
		}

		if (iNalTypePos > 0)	//nal_unit_type: 1-����������IDRͼ���е�Ƭ, 5-IDRͼ���е�Ƭ
		{
			int nal_unit_type = pBuf[iNalTypePos] & 0x1f;
			switch (nal_unit_type)
			{
			case h264_nal_slice_idr:
			{
				m_bFrameParseOk = true;
				return true;
			}

			case h264_nal_slice_non_idr:
				{
					if (bFindSPS && bFindPPS)	//����Ƶ֡I SliceҲΪ0x01 2017-08-29 Add
					{
						return true;
					}

					m_bFrameParseOk = true;
					return false;
				}

			case h264_nal_sps:
				{
					bFindSPS = true;
					if (nBufSize <= 200)  //SPS��IDR�ֿ����
					{
						m_bFrameParseOk = true;
						return true;
					}
				}
				break;

			case h264_nal_pps:
				{
					bFindPPS = true;
				}
				break;
			}		
		}
	}

	return false;
}

bool CPSFrameParser::IsH265IFrame(uint8_t* pBuf, uint32_t nBufSize)
{
	bool bFindSPS = false;
	bool bFindPPS = false;
	bool bFindVPS = false;

	//2�����H265
	for (int i = 0; i < STREAM_SCAN_LENGTH && i < nBufSize - 5; i++) //00 00 01 Ҳ��PS��ͷ
	{
		if (pBuf[i] == 0x00 && pBuf[i + 1] == 0x00 && pBuf[i + 2] == 0x00 && pBuf[i + 3] == 0x01)
		{
			int nal_unit_type = (pBuf[i + 4] & 0x7E) >> 1;
			switch (nal_unit_type)
			{
			case H265_NAL_IDR_W_RADL:
			{
				m_bFrameParseOk = true;
				return true;
			}

			case H265_NAL_TRAIL_R:
			{
				m_bFrameParseOk = true;
				return false;
			}

			case H265_NAL_VPS:
				bFindVPS = true;
				if (nBufSize <= 200)  //SPS��IDR�ֿ����
				{
					m_bFrameParseOk = true;
					return true;
				}
				break;

			case H265_NAL_SPS:
				bFindSPS = true;
				break;

			case H265_NAL_PPS:
				bFindPPS = true;
				break;

			default:
				if (H265_NAL_BLA_W_LP <= nal_unit_type && nal_unit_type <= H265_NAL_IRAP_VCL23)
				{
					if (bFindVPS && bFindSPS && bFindPPS)
					{
						m_bFrameParseOk = true;
						return true;
					}
				}
				break;
			}
		}
	}

	return false;
}

bool CPSFrameParser::IsMPEG4IFrame(uint8_t* pBuf, uint32_t nBufSize)
{
	for (int i = 0; i < STREAM_SCAN_LENGTH && i < nBufSize-4; i++) //00 00 01 Ҳ��PS��ͷ
	{
		if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x01 && pBuf[i+3] == 0xB6)
		{
			uint8_t byType = pBuf[i+4]&0xC0;

			if (byType == 0)	// I֡
			{
				m_bFrameParseOk = true;
				return true;
			}
			else if (byType == 0x40 || byType == 0x80)	//0x40 is P Frame, 0x80 is B Frame
			{
				m_bFrameParseOk = true;
				return false;
			}
		}
	}

	return false;
}

bool CPSFrameParser::IsSvacIFrame(uint8_t* pBuf, uint32_t nBufSize)
{
	bool bFindSPS = false;
	bool bFindPPS = false;

	//char tempBuf[600];
	//ZeroMemory(tempBuf, sizeof(tempBuf));
	//sprintf(tempBuf, "\n nBufSize = %d \t", nBufSize);
	//OutputDebugString(tempBuf);

	//for (int j = 0; j < 96; j++)
	//{
	//	sprintf(tempBuf+3*j, "%02X ", (uint8_t)pBuf[j]);
	//}
	//OutputDebugString(tempBuf);

	for (int i = 0; i < STREAM_SCAN_LENGTH && i < nBufSize-5; i++) //00 00 01 Ҳ��PS��ͷ
	{
		if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x00 && pBuf[i+3] == 0x01)
		{			
			int nal_unit_type = ((pBuf[i+4] & 0x3c)>>2);	
			switch (nal_unit_type)
			{
			case svac_nal_slice_non_idr:
			{
				m_bFrameParseOk = true;
				return false;
			}

			case svac_nal_slice_idr:
			{
				m_bFrameParseOk = true;
				return true;
			}

			case svac_nal_sps:
				bFindSPS = true;
				break;

			case svac_nal_pps:
				bFindPPS = true;
				break;
			}		
		}
	}

	return false;
}

//�ȼ��H264���ټ��H265���������SVAC�� �����MPEG4
bool CPSFrameParser::CheckStreamType(uint8_t* pBuf, uint32_t nBufSize)
{
	if (nBufSize <= 5)
		return false;

	int nal_unit_type = 0;
	//�ȼ��H264
	for (int i = 0; /*i < STREAM_SCAN_LENGTH && */i < nBufSize-5; i++) //00 00 01 Ҳ��PS��ͷ
	{
		if (pBuf[i] == 0x00 && pBuf[i + 1] == 0x00 && pBuf[i + 2] == 0x01)
		{
			if ((0xBA <= pBuf[i + 3] && pBuf[i + 3] <= 0xBD) || pBuf[i + 3] == 0xE0 || pBuf[i + 3] == 0xC0)
				continue;

			nal_unit_type = pBuf[i + 3] & 0x1f;
		}
		else if (pBuf[i] == 0x00 && pBuf[i + 1] == 0x00 && pBuf[i + 2] == 0x00 && pBuf[i + 3] == 0x01)
		{
			if ((0xBA <= pBuf[i + 4] && pBuf[i + 4] <= 0xBD) || pBuf[i + 4] == 0xE0 || pBuf[i + 4] == 0xC0)
				continue;

			nal_unit_type = pBuf[i + 4] & 0x1f;
		}
		else
		{
			continue;
		}

		switch (nal_unit_type)
		{
		case h264_nal_slice_idr:
		case h264_nal_slice_non_idr:
			if (m_bFindH264SPS || m_bFindH264PPS)
			{
				m_videoCodec = PS_h264;
				return true;
			}
			break;

		case h264_nal_sps:
			m_bFindH264SPS = true;			
			break;

		case h264_nal_pps:
			m_bFindH264PPS = true;
			break;
		}
	}

	//if (m_bFindH264SPS && nBufSize <= 200)  //SPS��IDR�ֿ����
	//{
	//	m_videoCodec = PS_h264;
	//	return true;
	//}
	
	//2�����H265
	for (int i = 0; /*i < STREAM_SCAN_LENGTH && */i < nBufSize - 5; i++) //00 00 01 Ҳ��PS��ͷ
	{
		if (pBuf[i] == 0x00 && pBuf[i + 1] == 0x00 && pBuf[i + 2] == 0x01)
		{
			if ((0xBA <= pBuf[i + 3] && pBuf[i + 3] <= 0xBD) || pBuf[i + 3] == 0xE0 || pBuf[i + 3] == 0xC0)
				continue;

			nal_unit_type = (pBuf[i + 3] & 0x7E) >> 1;
		}
		else if (pBuf[i] == 0x00 && pBuf[i + 1] == 0x00 && pBuf[i + 2] == 0x00 && pBuf[i + 3] == 0x01)
		{
			if ((0xBA <= pBuf[i + 4] && pBuf[i + 4] <= 0xBD) || pBuf[i + 4] == 0xE0 || pBuf[i + 4] == 0xC0)
				continue;

			nal_unit_type = (pBuf[i + 4] & 0x7E) >> 1;
		}
		else
		{
			continue;
		}

		switch (nal_unit_type)
		{
		case H265_NAL_IDR_W_RADL:
		case H265_NAL_TRAIL_R:
			if (m_bFindH265VPS || m_bFindH265SPS || m_bFindH265PPS)
			{
				m_videoCodec = PS_h265;
				return true;
			}
			break;

		case H265_NAL_VPS:
			m_bFindH265VPS = true;
			break;

		case H265_NAL_SPS:
			m_bFindH265SPS = true;
			break;

		case H265_NAL_PPS:
			m_bFindH265PPS = true;
			break;

		default:
			if (H265_NAL_BLA_W_LP <= nal_unit_type && nal_unit_type <= H265_NAL_IRAP_VCL23)
			{
				if (m_bFindH265VPS && m_bFindH265SPS && m_bFindH265PPS)
				{
					m_videoCodec = PS_h265;
					return true;
				}
			}
			break;
		}
	}

	if (m_bFindH265VPS && m_bFindH265SPS && m_bFindH265PPS)
	{
		m_videoCodec = PS_h265;
		return true;
	}

	//if (m_bFindH265VPS && nBufSize <= 200)  //SPS��IDR�ֿ����
	//{
	//	m_videoCodec = PS_h265;
	//	return true;
	//}

	//3 ���svac
	for (int i = 0; /*i < STREAM_SCAN_LENGTH && */i < nBufSize-5; i++) //00 00 01 Ҳ��PS��ͷ
	{
		if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x00 && pBuf[i+3] == 0x01)
		{
			if ((0xBA <= pBuf[i + 4] && pBuf[i + 4] <= 0xBD) || pBuf[i + 4] == 0xE0 || pBuf[i + 4] == 0xC0)
				continue;

			int nal_unit_type = ((pBuf[i+4] & 0x3c)>>2);	
			switch (nal_unit_type)
			{
			case svac_nal_slice_non_idr:
			case svac_nal_slice_idr:
				{
					if (m_bFindSvacSPS && m_bFindSvacPPS)
					{
						m_videoCodec = PS_svac;
						return true;
					}
				}
				break;

			case svac_nal_sps:
				m_bFindSvacSPS = true;
				break;

			case svac_nal_pps:
				m_bFindSvacPPS = true;
				break;
			}		
		}
	}

	if (m_bFindH264SPS || m_bFindH265SPS || m_bFindSvacSPS)
	{
		return false;
	}

	//4 ���MPEG4
	//00 00 01��ͷ
	int iNalTypePos = -1;
	for (int i = 0; /*i < STREAM_SCAN_LENGTH && */i < nBufSize-4; i++) //00 00 01 Ҳ��PS��ͷ
	{
		iNalTypePos = -1;
		if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x01)
		{
			iNalTypePos = i+3;

			if (pBuf[i+3] == 0xB0 || pBuf[i+3] == 0xB6) //MPEG4 
			{
				m_videoCodec = PS_mpeg4;
				return true;
			}
		}
	}

	return false;
}

bool CPSFrameParser::ParseH264Frame(uint8_t* pBuf, uint32_t nBufSize, H264_STREAM_INFO& streamInfo)
{
	int nalType = 0;
	int lastNalType = 0;
	int iLastNalStart = 0;
	int nPrefixBytes = 0;

	for (int i = 0; i <  nBufSize; i++)
	{
		nalType = 0;
		if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x01)
		{
			nalType = pBuf[i+3] & 0x1f;
			nPrefixBytes = 3;
		}
		else if (pBuf[i] == 0x00 && pBuf[i+1] == 0x00 && pBuf[i+2] == 0x00 && pBuf[i+3] == 0x01)
		{
			nalType = pBuf[i+4] & 0x1f;
			nPrefixBytes = 4;
		}
		else
		{
			continue;
		}

		switch (nalType)
		{
		case h264_nal_slice_idr:
		case h264_nal_slice_non_idr:
			{
				if (lastNalType == h264_nal_sps)
				{
					return h264_decode_sps(pBuf + iLastNalStart, i - iLastNalStart, streamInfo);
				}
				else
				{
					return false;	//��I֡��P֡ǰû�з���
				}
			}
			break;

		case h264_nal_sps:
		case h264_nal_pps:
			{
				if (lastNalType == h264_nal_sps)
				{
					return h264_decode_sps(pBuf + iLastNalStart, i - iLastNalStart, streamInfo);
				}

				lastNalType = nalType;
				iLastNalStart = i + nPrefixBytes;

				i += 4;
			}
			break;

		case h264_nal_sei:
			{
				if (lastNalType == h264_nal_sps)
				{
					return h264_decode_sps(pBuf + iLastNalStart, i - iLastNalStart, streamInfo);
				}

				lastNalType = h264_nal_sei;
			}
			break;
		}
	}

	return false;
}

uint32_t CPSFrameParser::Ue(uint8_t *pBuff, uint32_t nLen, uint32_t &nStartBit)
{
	//����0bit�ĸ���  
	uint32_t nZeroNum = 0;  
	while (nStartBit < nLen * 8)  
	{  
		if (pBuff[nStartBit / 8] & (0x80 >> (nStartBit % 8))) //&:��λ�룬%ȡ��  
		{  
			break;  
		}  
		nZeroNum++;  
		nStartBit++;  
	}  
	nStartBit ++;  


	//������  
	uint32_t dwRet = 0;  
	for (uint32_t i=0; i<nZeroNum; i++)  
	{  
		dwRet <<= 1;  
		if (pBuff[nStartBit / 8] & (0x80 >> (nStartBit % 8)))  
		{  
			dwRet += 1;  
		}  
		nStartBit++;  
	}  
	return (1 << nZeroNum) - 1 + dwRet;  
}

int CPSFrameParser::Se(uint8_t *pBuff, uint32_t nLen, uint32_t &nStartBit)
{
	int UeVal=Ue(pBuff,nLen,nStartBit);  
	double k=UeVal;  
	int nValue=ceil(k/2);//ceil������ceil��������������С�ڸ���ʵ������С������ceil(2)=ceil(1.2)=cei(1.5)=2.00  
	if (UeVal % 2==0)  
		nValue=-nValue;  
	return nValue;  
}

uint32_t CPSFrameParser::u(uint32_t BitCount,uint8_t * buf,uint32_t &nStartBit)  
{  
    uint32_t dwRet = 0;  
    for (uint32_t i=0; i<BitCount; i++)  
    {  
        dwRet <<= 1;  
        if (buf[nStartBit / 8] & (0x80 >> (nStartBit % 8)))  
        {  
            dwRet += 1;  
        }  
        nStartBit++;  
    }  
    return dwRet;  
}  
  
void CPSFrameParser::de_emulation_prevention(uint8_t* buf,unsigned int* buf_size)  
{  
    int i=0,j=0;  
    uint8_t* tmp_ptr=NULL;  
    unsigned int tmp_buf_size=0;  
    int val=0;  
  
    tmp_ptr=buf;  
    tmp_buf_size=*buf_size;  
    for(i=0;i<(tmp_buf_size-2);i++)  
    {  
        //check for 0x000003  
        val=(tmp_ptr[i]^0x00) +(tmp_ptr[i+1]^0x00)+(tmp_ptr[i+2]^0x03);  
        if(val==0)  
        {  
            //kick out 0x03  
            for(j=i+2;j<tmp_buf_size-1;j++)  
                tmp_ptr[j]=tmp_ptr[j+1];  
  
            //and so we should devrease bufsize  
            (*buf_size)--;  
        }  
    }  
}  
  
bool CPSFrameParser::h264_decode_sps(uint8_t * buf, uint32_t nLen, H264_STREAM_INFO& streamInfo)
{  
   uint32_t StartBit=0;  
    de_emulation_prevention(buf,&nLen);  
  
    int forbidden_zero_bit=u(1,buf,StartBit);  
    int nal_ref_idc=u(2,buf,StartBit);  
    int nal_unit_type=u(5,buf,StartBit);  
    if(nal_unit_type==7)  
    {  
		streamInfo.profile_idc = u(8, buf, StartBit);
        int constraint_set0_flag=u(1,buf,StartBit);//(buf[1] & 0x80)>>7;  
        int constraint_set1_flag=u(1,buf,StartBit);//(buf[1] & 0x40)>>6;  
        int constraint_set2_flag=u(1,buf,StartBit);//(buf[1] & 0x20)>>5;  
        int constraint_set3_flag=u(1,buf,StartBit);//(buf[1] & 0x10)>>4;  
        int reserved_zero_4bits=u(4,buf,StartBit);  
        int level_idc=u(8,buf,StartBit);  
  
        int seq_parameter_set_id=Ue(buf,nLen,StartBit);  
  
		if (streamInfo.profile_idc == 100 || streamInfo.profile_idc == 110 ||
			streamInfo.profile_idc == 122 || streamInfo.profile_idc == 144)
        {  
            int chroma_format_idc=Ue(buf,nLen,StartBit);  
            if( chroma_format_idc == 3 )  
                int residual_colour_transform_flag=u(1,buf,StartBit);  
            int bit_depth_luma_minus8=Ue(buf,nLen,StartBit);  
            int bit_depth_chroma_minus8=Ue(buf,nLen,StartBit);  
            int qpprime_y_zero_transform_bypass_flag=u(1,buf,StartBit);  
            int seq_scaling_matrix_present_flag=u(1,buf,StartBit);  
  
            int seq_scaling_list_present_flag[8];  
            if( seq_scaling_matrix_present_flag )  
            {  
                for( int i = 0; i < 8; i++ ) {  
                    seq_scaling_list_present_flag[i]=u(1,buf,StartBit);  
                }  
            }  
        }  
        int log2_max_frame_num_minus4=Ue(buf,nLen,StartBit);  
        int pic_order_cnt_type=Ue(buf,nLen,StartBit);  
        if( pic_order_cnt_type == 0 )  
            int log2_max_pic_order_cnt_lsb_minus4=Ue(buf,nLen,StartBit);  
        else if( pic_order_cnt_type == 1 )  
        {  
            int delta_pic_order_always_zero_flag=u(1,buf,StartBit);  
            int offset_for_non_ref_pic=Se(buf,nLen,StartBit);  
            int offset_for_top_to_bottom_field=Se(buf,nLen,StartBit);  
            int num_ref_frames_in_pic_order_cnt_cycle=Ue(buf,nLen,StartBit);  
  
            int *offset_for_ref_frame=new int[num_ref_frames_in_pic_order_cnt_cycle];  
            for( int i = 0; i < num_ref_frames_in_pic_order_cnt_cycle; i++ )  
                offset_for_ref_frame[i]=Se(buf,nLen,StartBit);  
            delete [] offset_for_ref_frame;  
        }  
        int num_ref_frames=Ue(buf,nLen,StartBit);  
        int gaps_in_frame_num_value_allowed_flag=u(1,buf,StartBit);  
        int pic_width_in_mbs_minus1=Ue(buf,nLen,StartBit);  
        int pic_height_in_map_units_minus1=Ue(buf,nLen,StartBit);  
  
		streamInfo.nWidth = (pic_width_in_mbs_minus1 + 1) * 16;
		streamInfo.nHeight = (pic_height_in_map_units_minus1 + 1) * 16;
  
        int frame_mbs_only_flag=u(1,buf,StartBit);  
        if(!frame_mbs_only_flag)  
            int mb_adaptive_frame_field_flag=u(1,buf,StartBit);  
  
        int direct_8x8_inference_flag=u(1,buf,StartBit);  
        int frame_cropping_flag=u(1,buf,StartBit);  
        if(frame_cropping_flag)  
        {  
            int frame_crop_left_offset=Ue(buf,nLen,StartBit);  
            int frame_crop_right_offset=Ue(buf,nLen,StartBit);  
            int frame_crop_top_offset=Ue(buf,nLen,StartBit);  
            int frame_crop_bottom_offset=Ue(buf,nLen,StartBit);  
        }  
        int vui_parameter_present_flag=u(1,buf,StartBit);  
        if(vui_parameter_present_flag)  
        {  
            int aspect_ratio_info_present_flag=u(1,buf,StartBit);  
            if(aspect_ratio_info_present_flag)  
            {  
                int aspect_ratio_idc=u(8,buf,StartBit);  
                if(aspect_ratio_idc==255)  
                {  
                    int sar_width=u(16,buf,StartBit);  
                    int sar_height=u(16,buf,StartBit);  
                }  
            }  
            int overscan_info_present_flag=u(1,buf,StartBit);  
            if(overscan_info_present_flag)  
                int overscan_appropriate_flagu=u(1,buf,StartBit);  
            int video_signal_type_present_flag=u(1,buf,StartBit);  
            if(video_signal_type_present_flag)  
            {  
                int video_format=u(3,buf,StartBit);  
                int video_full_range_flag=u(1,buf,StartBit);  
                int colour_description_present_flag=u(1,buf,StartBit);  
                if(colour_description_present_flag)  
                {  
                    int colour_primaries=u(8,buf,StartBit);  
                    int transfer_characteristics=u(8,buf,StartBit);  
                    int matrix_coefficients=u(8,buf,StartBit);  
                }  
            }  
            int chroma_loc_info_present_flag=u(1,buf,StartBit);  
            if(chroma_loc_info_present_flag)  
            {  
                int chroma_sample_loc_type_top_field=Ue(buf,nLen,StartBit);  
                int chroma_sample_loc_type_bottom_field=Ue(buf,nLen,StartBit);  
            }  
            int timing_info_present_flag=u(1,buf,StartBit);  
  
            if(timing_info_present_flag)  
            {  
                int num_units_in_tick=u(32,buf,StartBit);  
                int time_scale=u(32,buf,StartBit);  
				streamInfo.fps = time_scale / num_units_in_tick;
                int fixed_frame_rate_flag=u(1,buf,StartBit);  
                if(fixed_frame_rate_flag)  
                {  
					streamInfo.fps = streamInfo.fps / 2;
                }  
            }  
        }  
        return true;  
    }  

	return false;  
}  
