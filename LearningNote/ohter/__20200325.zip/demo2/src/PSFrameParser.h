#pragma once
#include "PSStruct.h"

enum H264_NAL_TYPE
{
	h264_nal_sps			= 0x07,			//Sequence parameter set
	h264_nal_pps			= 0x08,			//Picture parameter set
	h264_nal_slice_idr		= 0x05,			//Coded slice of an IDR picture
	h264_nal_slice_non_idr	= 0x01,			//Coded slice of a non-IDR picture
	h264_nal_sei			= 0x06,			//Supplemental enhancement information
	h264_nal_delimiter		= 0x09,			//Access unit delimiter
};

enum H265_NAL_TYPE
{
	H265_NAL_TRAIL_N = 0,
	H265_NAL_TRAIL_R = 1,
	H265_NAL_TSA_N = 2,
	H265_NAL_TSA_R = 3,
	H265_NAL_STSA_N = 4,
	H265_NAL_STSA_R = 5,
	H265_NAL_RADL_N = 6,
	H265_NAL_RADL_R = 7,
	H265_NAL_RASL_N = 8,
	H265_NAL_RASL_R = 9,
	H265_RSV_VCL_N10 = 10,
	H265_RSV_VCL_R11 = 11,
	H265_RSV_VCL_N12 = 12,
	H265_RSV_VCL_R13 = 13,
	H265_RSV_VCL_N14 = 14,
	H265_RSV_VCL_R15 = 15,
	H265_NAL_BLA_W_LP = 16,
	H265_NAL_BLA_W_RADL = 17,
	H265_NAL_BLA_N_LP = 18,
	H265_NAL_IDR_W_RADL = 19,
	H265_NAL_IDR_N_LP = 20,
	H265_NAL_CRA_NUT = 21,
	H265_NAL_IRAP_VCL22 = 22,
	H265_NAL_IRAP_VCL23 = 23,
	H265_NAL_VPS = 32,
	H265_NAL_SPS = 33,
	H265_NAL_PPS = 34,
	H265_NAL_AUD = 35,
	H265_NAL_EOS_NUT = 36,
	H265_NAL_EOB_NUT = 37,
	H265_NAL_FD_NUT = 38,
	H265_NAL_SEI_PREFIX = 39,
	H265_NAL_SEI_SUFFIX = 40,
	H265_NAL_RSV_NVCL41 = 41,
	H265_NAL_RSV_UNSPEC63 = 63,

	H265_NAL_UNKNOWN = 64,
};

enum SVAC_NAL_TYPE
{
	svac_nal_sps = 0x07,			//Sequence parameter set
	svac_nal_pps = 0x08,			//Picture parameter set
	svac_nal_slice_idr = 0x02,			//Coded slice of an IDR picture
	svac_nal_slice_non_idr = 0x01,			//Coded slice of a non-IDR picture
	svac_nal_sei = 0x06,			//Supplemental enhancement information
};

struct H264_STREAM_INFO 
{
	int profile_idc;
	int nWidth;
	int nHeight;
	int	fps;

	H264_STREAM_INFO()
	{
		memset(this, 0, sizeof(H264_STREAM_INFO));
	}	
};

const int H264_SCAN_LENGTH = 800;


//��Ҫ����H264�ı����������
class CPSFrameParser
{
public:
	CPSFrameParser(void);
	~CPSFrameParser(void);

	bool IsIFrame(uint8_t* pBuf, uint32_t nBufSize);
	bool IsIFrameEx(uint8_t* pBuf, uint32_t nBufSize, bool& bFrameParseOk);
	void Reset();

	bool CheckStreamType(uint8_t* pBuf, uint32_t nBufSize);	//2017-10-10 Add
	PS_VIDEO_CODEC GetVideoCodec() { return m_videoCodec; }

	bool ParseH264Frame(uint8_t* pBuf, uint32_t nBufSize, H264_STREAM_INFO& streamInfo);

	bool h264_decode_sps(uint8_t * buf, uint32_t nLen, H264_STREAM_INFO& streamInfo);

private:
	bool IsH264IFrame(uint8_t* pBuf, uint32_t nBufSize);
	bool IsH265IFrame(uint8_t* pBuf, uint32_t nBufSize);
	bool IsMPEG4IFrame(uint8_t* pBuf, uint32_t nBufSize);
	bool IsSvacIFrame(uint8_t* pBuf, uint32_t nBufSize);

	uint32_t Ue(uint8_t *pBuff, uint32_t nLen, uint32_t &nStartBit);

	int Se(uint8_t *pBuff, uint32_t nLen, uint32_t &nStartBit); 

	uint32_t u(uint32_t BitCount,uint8_t * buf,uint32_t &nStartBit);

	void de_emulation_prevention(uint8_t* buf,unsigned int* buf_size);


private:
	PS_VIDEO_CODEC	m_videoCodec;		

	bool	m_bFindH264SPS;
	bool	m_bFindH264PPS;

	bool	m_bFindH265SPS;
	bool	m_bFindH265PPS;
	bool	m_bFindH265VPS;

	bool	m_bFindSvacSPS;
	bool	m_bFindSvacPPS;

	bool	m_bFrameParseOk;
};
