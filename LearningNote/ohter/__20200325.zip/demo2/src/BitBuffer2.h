#pragma once
#include <stdint.h>
#include <string.h>

class CBitBuffer2
{
public:
	CBitBuffer2(void);
	~CBitBuffer2(void);

	void set_buf(uint8_t* buf, int bufsize, bool clear = true);  

	void set_bits(uint32_t val, int bits);

	void set_bit_pos(uint32_t newpos);   

	void set_byte_pos(uint32_t newpos);   

	uint32_t get_bits(int bits);   

	int buf_size() { return m_bitpos >> 3; } 

	uint32_t get_bit_pos()  {   return m_bitpos;  }   
	uint32_t get_byte_pos() {  return m_bitpos >> 3; }   


private:
	int		m_bitpos;   
	uint32_t	m_bitval;   
	uint8_t*	m_bitbuf;   
};
