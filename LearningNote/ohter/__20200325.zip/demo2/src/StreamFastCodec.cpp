﻿#include "StreamFastCodec.h"
#include "quicklog.h"


CStreamFastCodec::CStreamFastCodec(uint32_t cacheNumMax)
    : _pushSizeCnt(0)
    , _getSizeCnt(0)
    , _cacheNumMax(cacheNumMax)
{
}

CStreamFastCodec::~CStreamFastCodec() 
{
}

bool CStreamFastCodec::PushOneFrame(const FRAME_INFO_T& frame)
{
    if (!frame.pFrameData
        || !0 == frame.lFrameSize) {
        return false;
    }

    bool isPushOk = false;
    uint8_t* pushData = nullptr;
    uint32_t pushSize = frame.lFrameSize;
    uint32_t bufFreeSize = _toEsFrame.GetBufFreeSize();

    if (!_cacheList.empty()) {
        for (auto& _frame : _cacheList) {
            pushSize += _frame->lFrameSize;
        }

        if (0 < bufFreeSize && bufFreeSize <= pushSize) {
            QCLOG(QC_LOG_WARN, "maybe abandon data! lFrameSize(%u) pushSize(%u) bufFreeSize(%u)\n",
                frame.lFrameSize, pushSize, bufFreeSize);
        }

        pushData = new uint8_t[pushSize];
        int pushPos = 0;
        for (auto& _frame : _cacheList) {
            memcpy(pushData + pushPos, _frame->pFrameData, _frame->lFrameSize);
            pushPos += _frame->lFrameSize;
        }
        memcpy(pushData + pushPos, frame.pFrameData, frame.lFrameSize);

        isPushOk = _toEsFrame.PushStream(pushData, pushSize);

        delete[] pushData;
    }
    else {
        if (0 < bufFreeSize && bufFreeSize <= pushSize) {
            QCLOG(QC_LOG_WARN, "maybe abandon data! lFrameSize(%u) pushSize(%u) bufFreeSize(%u)\n",
                frame.lFrameSize, pushSize, bufFreeSize);
        }

        pushData = frame.pFrameData;
        isPushOk = _toEsFrame.PushStream(pushData, pushSize);
    }

    if (!isPushOk) {
        QCLOG(QC_LOG_ERROR, "fail with lFrameSize(%u) pushSize(%u)\n", frame.lFrameSize, pushSize);
        PushQueue(frame);
        return false;
    }
    else {
        ClearQueue();
    }

    _pushSizeCnt += pushSize;
    return true;
}

bool CStreamFastCodec::GetOneEsFrame(ES_FRAME_INFO& esFrame)
{
    if (!_toEsFrame.HasMultipleFrame())
        return false;

    if (!_toEsFrame.GetFrame(esFrame)) {
        return false;
    }

    if (!esFrame.pFrameData || 0 == esFrame.lFrameSize)
        return false;

    _getSizeCnt += esFrame.lFrameSize;

    if (esFrame.bIFrame) {
        QCLOG(QC_LOG_ERROR, "find IFrame _pushSizeCnt(%u) _getSizeCnt(%u) _cacheList.size(%u) GetBufFreeSize(%u)\n",
            _pushSizeCnt, _getSizeCnt, _cacheList.size(), _toEsFrame.GetBufFreeSize());
    }

    return true;
}

bool CStreamFastCodec::GetOnePsFrame(ES_FRAME_INFO& esFrame, uint8_t*& psFrameData, uint32_t& psFrameSize)
{
    if (!GetOneEsFrame(esFrame))
        return false;

    psFrameSize = MAX_PS_LENGTH;
    psFrameData = new uint8_t[psFrameSize];

    if (!esFrame.bAudio) {
        psFrameSize = _psPacket.PSPacket(esFrame.pFrameData, esFrame.lFrameSize, 0,
            esFrame.bIFrame ? PS_H264_I_FRAME : PS_H264_P_FRAME,
            psFrameData, psFrameSize);
    }
    else {
        psFrameSize = _psPacket.PSAudio(esFrame.pFrameData, esFrame.lFrameSize, 1,
            psFrameData, psFrameSize);
    }

    if (!psFrameData || 0 == psFrameSize) {
        delete[] psFrameData;
        psFrameData = nullptr;
        psFrameSize = 0;
        return false;
    }

    return true;
}

FRAME_INFO_T* CStreamFastCodec::CopyFrame(const FRAME_INFO_T* frame)
{
    if (!frame
        || !frame->pFrameData)
        return nullptr;

    FRAME_INFO_T* newFrame = new FRAME_INFO_T();
    *newFrame = *frame;
    newFrame->pFrameData = new uint8_t[newFrame->lFrameSize];
    memcpy(newFrame->pFrameData, frame->pFrameData, frame->lFrameSize);
    return newFrame;
}

void CStreamFastCodec::FreeFrame(const FRAME_INFO_T* frame)
{
    if (frame) {
        if (frame->pFrameData) {
            delete[] frame->pFrameData;
        }
        delete frame;
    }
}

void CStreamFastCodec::PushQueue(const FRAME_INFO_T& frame)
{
    FRAME_INFO_T* newFrame = CopyFrame(&frame);
    if (newFrame) {
        _cacheList.push_back(newFrame);

        if (_cacheNumMax < _cacheList.size()) {
            FreeFrame(_cacheList.front());
            _cacheList.pop_front();
        }
    }
}

void CStreamFastCodec::ClearQueue()
{
    if (!_cacheList.empty()) {
        for (auto& frame : _cacheList) {
            FreeFrame(frame);
        }
        _cacheList.clear();
    }
}

