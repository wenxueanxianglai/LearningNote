#ifndef _FRAMEIO_H_
#define _FRAMEIO_H_

#include <iostream>
#include <string>
#include <list>
#include <map>
#include <fstream>
#include "common.h"

#pragma warning(disable:4996)

class CFrameIO
{
public:
	enum EFrame { emIFrame, emPFrame, emBFrame, emAudio, emUnknown };

	typedef struct TFrame {
		TFrame() 
            : type(emUnknown), index(0), size(0), data(NULL) {}

        EFrame type;
		int index;
		int size;
		uint8_t* data;
	} TFrame;

    typedef struct TStream {
        TStream()
            : stream_index(-1)
            , bit_rate(0)
            , sample_rate(0)
            , width(0)
            , height(0)
            , extradata_size(0)
            , extradata(NULL)
            , is_frag_keyframe(false) {}

        int stream_index;
        std::string codec_tag;
        int64_t bit_rate;
        int sample_rate;
        int width;
        int height;
        uint8_t* extradata;
        int extradata_size;
        bool is_frag_keyframe;
    } TStream;

    void AddStream(TStream* stream);
    void AddFrame(int stream_index, TFrame* frame);
    const TStream* GetStream(int stream_index) const;
    const TFrame* GetFrame(int stream_index, int frame_index) const;
    int GetFrameNum(int stream_index) const;
    int GetVideoFrameNum(int stream_index) const;
    int GetAudioFrameNum(int stream_index) const;
    void SaveVideoFrame(int stream_index);
    void SaveAudioFrame(int stream_index);

protected:
    CFrameIO(const std::string baseName) : _baseName(baseName) {}

    std::string _baseName;
    std::map<int, TStream*> _streamMap;
	std::map<int, std::list<TFrame*>> _frameMap;
};

class CFrameFileIO : public CFrameIO
{
public:
    CFrameFileIO(const std::string& baseName)
        : CFrameIO(baseName) {}

    void Read(const std::string& datPath,
        int streamIndex, int keyFrameSizeMin, int audioFrameSizeMax);

    void Read(const std::string& datPath, const std::string& txtPath,
        int streamIndex, int keyFrameSizeMin, int audioFrameSizeMax);
};


#endif //_FRAMEIO_H_

