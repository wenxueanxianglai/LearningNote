#pragma once

#include <stdint.h>

class NALUnit
{
public:
    NALUnit();
    virtual ~NALUnit() {}

    // assignment copies a pointer into a fixed buffer managed elsewhere. We do not copy the data
    NALUnit(const NALUnit& r)
    {
        m_pStart = r.m_pStart;
        m_cBytes = r.m_cBytes;
        ResetBitstream();
    }
    const NALUnit& operator=(const NALUnit& r)
    {
        m_pStart = r.m_pStart;
        m_cBytes = r.m_cBytes;
        ResetBitstream();
        return *this;
    }

    enum eNALType
    {
        NAL_Slice = 1,
        NAL_PartitionA = 2,
        NAL_PartitionB = 3,
        NAL_PartitionC = 4,
        NAL_IDR_Slice = 5,
        NAL_SEI = 6,
        NAL_Sequence_Params = 7,
        NAL_Picture_Params = 8,
        NAL_AUD = 9,

        /* H265 */
        NAL_TRAIL_N = 0,
        NAL_TRAIL_R = 1,
        NAL_TSA_N = 2,
        NAL_TSA_R = 3,
        NAL_STSA_N = 4,
        NAL_STSA_R = 5,
        NAL_RADL_N = 6,
        NAL_RADL_R = 7,
        NAL_RASL_N = 8,
        NAL_RASL_R = 9,
        NAL_BLA_W_LP = 16,
        NAL_BLA_W_RADL = 17,
        NAL_BLA_N_LP = 18,
        NAL_IDR_W_RADL = 19,
        NAL_IDR_N_LP = 20,
        NAL_CRA_NUT = 21,
        NAL_VPS = 32,
        NAL_SPS = 33,
        NAL_PPS = 34,
        //NAL_AUD        = 35,
        NAL_EOS_NUT = 36,
        NAL_EOB_NUT = 37,
        NAL_FD_NUT = 38,
        NAL_SEI_PREFIX = 39,
        NAL_SEI_SUFFIX = 40,
        /* SVAC */
        NAL_RESERVED_1 = 0,
        NAL_slice_layer_rbsp_1 = 1,
        NAL_slice_layer_rbsp_2 = 2,
        NAL_slice_layer_rbsp_3 = 3,
        NAL_slice_layer_rbsp_4 = 4,
        NAL_surveillance_extension_rbsp = 5,
        NAL_sei_rbsp = 6,
        NAL_seq_parameter_set_rbsp = 7,
        NAL_pic_parameter_set_rbsp = 8,
        NAL_sec_parameter_set_rbsp = 9,
        NAL_end_of_seq_rbsp = 10,
        end_of_stream_rbs = 11,
        NAL_filler_data_rbsp = 12,
        //NAL_RESERVED_ = 0,
        NAL_RESERVED_2 = 13,
        NAL_RESERVED_3 = 14,
    };

    // identify a NAL unit within a buffer.
    // If LengthSize is non-zero, it is the number of bytes
    // of length field we expect. Otherwise, we expect start-code
    // delimiters.
    bool Parse(const uint8_t* pBuffer, int32_t cSpace, int32_t LengthSize, bool bEnd);

    eNALType Type(int32_t type = 0)
    {
        if (m_pStart == NULL)
        {
            return eNALType(0);
        }
        if (type == 0) /* H264 */
            return eNALType(m_pStart[0] & 0x1F);
        else if (type == 1) /* H265*/
            return eNALType(m_pStart[0] >> 1 & 0x3F);
        else if (type == 2) /* SVAC*/
            return eNALType(m_pStart[0] >> 2 & 0x0F);
        else    return eNALType(0);
    }

    int32_t Length()
    {
        return m_cBytes;
    }

    const uint8_t* Start()
    {
        return m_pStart;
    }

    // bitwise access to data
    void ResetBitstream();
    void Skip(int32_t nBits);

    uint32_t GetWord(int32_t nBits);
    uint8_t GetBYTE();
    uint32_t GetBit();

    const uint8_t* StartCodeStart() { return m_pStartCodeStart; }
    uint32_t GetStartCodeSize() { return m_startCodeSize; }

private:
    bool GetStartCode(const uint8_t*& pBegin, const uint8_t*& pStart, int32_t& cRemain);

private:
    const uint8_t* m_pStartCodeStart;
    const uint8_t* m_pStart;
    int32_t m_cBytes;

    // bitstream access
    int32_t m_idx;
    int32_t m_nBits;
    uint8_t m_byte;
    int32_t m_cZeros;
    int32_t m_startCodeSize;
};

class NALUnitRBSP
{
public:
    NALUnitRBSP(NALUnit &nal);
    ~NALUnitRBSP();

    uint32_t GetBits(int bits);
    uint64_t GetBitsLong(int bits);

    unsigned GetUEGolomb();
    int GetSEGolomb();

    int SkipBits(int bits);
    int ResetBit(int bit = 0);
    int GetBit();
    int GetBitLeft();
private:
    uint32_t ShowBits(int bits);
    uint64_t ShowBitsLong(int bits);
    
private:
    uint8_t* rbsp;
    int mSize;
    int mSizeInBit;

    int mBit;
private:
    NALUnitRBSP();
};

typedef struct HEVCDecoderConfigurationRecord {
    uint8_t  configurationVersion;
    uint8_t  general_profile_space;
    uint8_t  general_tier_flag;
    uint8_t  general_profile_idc;
    uint32_t general_profile_compatibility_flags;
    uint64_t general_constraint_indicator_flags;
    uint8_t  general_level_idc;
    uint16_t min_spatial_segmentation_idc;
    uint8_t  parallelismType;
    uint8_t  chromaFormat;
    uint8_t  bitDepthLumaMinus8;
    uint8_t  bitDepthChromaMinus8;
    uint16_t avgFrameRate;
    uint8_t  constantFrameRate;
    uint8_t  numTemporalLayers;
    uint8_t  temporalIdNested;
    uint8_t  lengthSizeMinusOne;
    uint8_t  numOfArrays;
} HEVCDecoderConfigurationRecord;

typedef struct HVCCProfileTierLevel {
    uint8_t  profile_space;
    uint8_t  tier_flag;
    uint8_t  profile_idc;
    uint32_t profile_compatibility_flags;
    uint64_t constraint_indicator_flags;
    uint8_t  level_idc;
} HVCCProfileTierLevel;

void hvcc_update_ptl(HVCCProfileTierLevel *ptl, HEVCDecoderConfigurationRecord& hvcc);

inline void WriteLong(long l, uint8_t* pBuffer)
{
    pBuffer[0] = uint8_t(l >> 24);
    pBuffer[1] = uint8_t((l >> 16) & 0xff);
    pBuffer[2] = uint8_t((l >> 8) & 0xff);
    pBuffer[3] = uint8_t(l & 0xff);
}