#include "common.h"


int GetFileSize(const char *path) {
	struct stat st;
	int ret;

	ret = stat(path, &st);
	if (-1 == ret) {
		printf("stat(%s)=-1,{%d:%s}\n", path, errno, strerror(errno));
		return -1;
	}
	else
		return st.st_size;
}

int GetFileBuffer(const char *path, void *buffer, int size) {
	FILE *file = NULL;
	int fsize;
	int result = -1;

	file = fopen(path, "rb");
	if (NULL == file)
		printf("fopen(%s)=NULL,{%d:%s}\n", path, errno, strerror(errno));
	else {
		fsize = GetFileSize(path);
		if (-1 != fsize && size >= fsize) {
			fread(buffer, fsize, sizeof(char), file);
			result = fsize;
		}
		fclose(file);
	}
	return result;
}

bool GetNameFromPath(const char *path, char *name, int size) {
    char tmppath[256] = { 0 };
    strcpy(tmppath, path);

    char *destpath = tmppath;
    char *lastseq = strrchr(destpath, PATH_SEPCHAR);
    if (lastseq) {
        int lenseq = lastseq - destpath + 1;
        destpath += lenseq;
    }

    char *token = strtok(destpath, ".");
    for (int i = 0; token; i++) {
        if (0 == i) {
            strcpy(name, token);
            return true;
        }
        token = strtok(NULL, ".");
    }

    return false;
}

bool GetExtFromPath(const char *path, char *ext, int size) {
    char tmppath[256] = { 0 };
    strcpy(tmppath, path);

    char *destpath = tmppath;
    char *lastseq = strrchr(destpath, PATH_SEPCHAR);
    if (lastseq) {
        int lenseq = lastseq - destpath + 1;
        destpath += lenseq;
    }

    char *token = strtok(destpath, ".");
    for (int i = 0; token; i++) {
        if (1 == i) {
            strcpy(ext, token);
            return true;
        }
        token = strtok(NULL, ".");
    }

    return false;
}

