#pragma once
#include "BitBuffer2.h"

const uint32_t NAL_HEADER_LENGTH = 5;

const uint32_t NAL_SLICE_HEAD_LENGTH = 8;  

enum ESStatus
{
	es_padding,			//未知状态
	es_sps,				//Sequence parameter set
	es_pps,				//Picture parameter set
	es_slice_idr,		//Coded slice of an IDR picture
	es_slice_non_idr,	//Coded slice of a non-IDR picture
	es_sei,				//Supplemental enhancement information

	es_kd_audio,		//科达音频流 nal_unit_type is 26
};

class CESAnalyzer
{
public:
	CESAnalyzer(void);
	~CESAnalyzer(void);

	ESStatus GetNextStatus(uint8_t* pPSBuffer, uint32_t& nESIndicator, uint32_t nPSWritePos);

	uint32_t get_first_mb_in_slice() { return m_first_mb_in_slice; }

private:
	void calc_first_mb_in_slice(uint8_t* pStartPos);


private:
	CBitBuffer2		m_bitBuffer;

	uint32_t	m_first_mb_in_slice;

};
