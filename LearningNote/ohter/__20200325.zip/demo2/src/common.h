#ifndef _COMMON_H_
#define _COMMON_H_


#ifdef _WIN32
#include <direct.h>
#include <io.h>
#else
#include <unistd.h>
#include <fcntl.h>
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sstream>
#include <string>
#include <list>
#include <vector>
#include "quicklog.h"

#pragma warning(disable:4996)


#ifdef _WIN32
#define PATH_SEPCHAR   '\\'
#define PATH_SEPSTR    "\\"
#define MKDIR(s)       mkdir(s);
#define fflog(level, ...)  ffprint(level, __FUNCTION__, ##__VA_ARGS__)
#else
#define PATH_SEPCHAR   '/'
#define PATH_SEPSTR    "/"
#define MKDIR(s)       mkdir(s, 0755);
#define fflog(level, ...)  ffprint(level, __FUNCTION__, ##__VA_ARGS__)
#endif


int GetFileSize(const char *path);
int GetFileBuffer(const char *path, void *buffer, int size);
bool GetNameFromPath(const char *path, char *name, int size);
bool GetExtFromPath(const char *path, char *ext, int size);


#endif //_COMMON_H_
